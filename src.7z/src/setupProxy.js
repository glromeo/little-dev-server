const createProxyMiddleware = require("http-proxy-middleware");
const { existsSync, readFileSync } = require("fs");

function sendFixture(req, res, path, minDelay = 0, maxDelay = 1000) {
    path = `test/fixtures/${path}`;
    if (existsSync(path)) {
        const delayMs = minDelay + Math.random() * (maxDelay - minDelay);
        console.log(`${req.method} ${req.originalUrl} -> ${path} (delayed of: ${delayMs}ms)`);
        setTimeout(() => res.json(JSON.parse(readFileSync(path, "utf-8"))), delayMs);
        return true;
    } else {
        return false;
    }
}

const createDashboardRedirect =
    ({ target }) =>
    (req, res, next) => {
        if (req.header("User-Agent").endsWith("AWC/3.4")) {
            console.log(`[AWC] redirect: ${req.method} ${req.originalUrl} -> ${target}`);
            res.redirect(308, `${target}${req.originalUrl}`);
        } else {
            return next();
        }
    };

function router(header) {
    return req => {
        switch (String(req.header(header)).toLowerCase()) {
            case "dev-http":
                return "http://dev.blackrock.com";
            case "dev":
                return "https://dev.blackrock.com";
            case "tst":
                return "https://tst.blackrock.com";
            case "prod":
                return "https://webster.bfm.com";
            default:
                return "http://localhost:59042";
        }
    };
}

function parseBody(req, res) {
    return new Promise((resolve, reject) => {
        let payload = "",
            body;
        req.on("data", chunk => {
            payload += chunk;
        });
        req.on("error", reject);
        req.on("end", () => {
            resolve(JSON.parse(payload));
        });
    });
}

/**
 *
 * @param {Express} app
 */
module.exports = function (app) {

    app.get("/settings", function (req, res) {
        sendFixture(req, res, "settings.json");
    });

    app.post("/settings", function (req, res) {
        console.log("saving settings is ignored");
    });

    app.use("/api", function (req, res, next) {
        if (!sendFixture(req, res, id === "0" ? "axe.json" : `axes/${id}.json`)) {
            return next();
        }
    });

    // app.use("/oemsgqlserver", async function (req, res, next) {
    //     const body = await parseBody(req, res);
    //     const { query, variables } = body;
    //     if (variables.ordNum === 0) {
    //         if (variables.brokerList === undefined) {
    //             sendFixture(req, res, `graphql/order.json`);
    //         } else {
    //             sendFixture(req, res, `graphql/brokers.json`);
    //         }
    //         return;
    //     }
    //     if (variables.ordNum === 1) {
    //         if (variables.brokerList === undefined) {
    //             sendFixture(req, res, `graphql/order.json`);
    //         } else {
    //             sendFixture(req, res, `graphql/brokers.json`);
    //         }
    //         return;
    //     }
    //     res.end();
    // });

    const target = "https://tst.blackrock.com";

    app.use(
        "/oemsgqlserver",
        createDashboardRedirect({ target }),
        createProxyMiddleware({
            target,
            changeOrigin: true,
            router: router("X-GQL-ENV"),
            logLevel: "debug",
        })
    );

    app.use(
        "/api",
        createDashboardRedirect({ target }),
        createProxyMiddleware({
            target,
            changeOrigin: true,
            router: router("X-API-ENV"),
            logLevel: "debug",
        })
    );
};

import { combineReducers, createReducer } from "@reduxjs/toolkit";
import {
    applySort,
    clearAxes,
    clearOrder,
    clearSort,
    closeSettings,
    debugInfo,
    expireAxe,
    fetchAxes,
    fetchBrokerDetails,
    fetchLiquidityScoreData,
    fetchOrderMetrics,
    fetchOrderSummary,
    filterLimit,
    filterMinSize,
    filterRestricted,
    filterSource,
    insertAxe,
    loadSettings,
    notifyAlert,
    openSettings,
    saveSettings,
    setColumns,
} from "./actions";
import { Order, OrderMetrics, OrderSummary } from "../models/order";
import { Axes } from "../models/axe";
import { Alert, ApiError, AsyncRejection, shouldNotify, toAlert, toApiError } from "../models/alerts";
import { Security } from "../models/security";
import { loadFromLocalStorage, Settings } from "../models/settings";
import { DEFAULT_FILTERS, Filters } from "../models/filtering";
import { BrokerDetails } from "../models/brokers";

const order = createReducer<Order | null>(null, builder =>
    builder
        .addCase(clearOrder, () => null)
        .addCase(fetchOrderSummary.fulfilled, (current, { payload: { order } }) => order)
);

const orderNumber = createReducer<number | null>(null, builder =>
    builder.addCase(fetchOrderSummary.fulfilled, (current, { payload: order }) => order.orderNumber)
);

const security = createReducer<Security | null>(null, builder =>
    builder.addCase(fetchOrderSummary.fulfilled, (current, { payload: { security } }) => security)
);

const liquidityScore = createReducer<number | null>(null, builder =>
    builder.addCase(fetchLiquidityScoreData.fulfilled, (current, { payload: liquidity }) => liquidity)
);

const orderSummary = combineReducers<OrderSummary>({
    orderNumber,
    order,
    security,
});

const orderMetrics = createReducer<OrderMetrics | null>(null, builder =>
    builder.addCase(fetchOrderMetrics.fulfilled, (current, { payload: orderMetrics }) => orderMetrics)
);

const filters = createReducer<Filters>(DEFAULT_FILTERS, builder =>
    builder
        .addCase(filterSource, (current, { payload: sources }) => {
            if (current.sources !== sources) {
                current.sources = sources;
            }
        })
        .addCase(filterMinSize, (current, { payload: minSize }) => {
            if (current.minSize !== minSize) {
                current.minSize = minSize;
            }
        })
        .addCase(filterLimit, (current, { payload: limit }) => {
            if (current.limit !== limit) {
                current.limit = limit;
            }
        })
        .addCase(filterRestricted, (current, { payload: hideRestricted }) => {
            if (current.hideRestricted !== hideRestricted) {
                current.hideRestricted = hideRestricted;
            }
        })
        .addCase(fetchBrokerDetails.fulfilled, (current, { payload: { allocations } }) => {
            const restrictedBrokers = new Set<number>();
            if (allocations)
                for (const allocation of allocations) {
                    if (allocation.eligiblePlacementQuantityAsPct === 0) {
                        restrictedBrokers.add(allocation.broker.code);
                    }
                }
            return {
                ...current,
                restrictedBrokers,
            };
        })
);

const brokerDetails = createReducer({} as BrokerDetails, builder => {
    builder.addCase(fetchBrokerDetails.fulfilled, (current, { payload: brokerDetails }) => {
        return {
            ...current,
            ...brokerDetails,
        };
    });
});

const reduceUserAlerts = (alerts: Alert[], { error }: AsyncRejection) => {
    return shouldNotify(error) ? [...alerts, toAlert(error)] : alerts;
};

const alerts = createReducer<Alert[]>([], builder =>
    builder
        .addCase(notifyAlert, (alerts, { payload: alert }) => {
            return [...alerts, alert];
        })
        .addCase(fetchAxes.rejected, reduceUserAlerts)
        .addCase(fetchOrderSummary.rejected, reduceUserAlerts)
        .addCase(fetchBrokerDetails.rejected, reduceUserAlerts)
        .addCase(fetchOrderMetrics.rejected, reduceUserAlerts)
        .addCase(fetchLiquidityScoreData.rejected, reduceUserAlerts)
);

const debug = createReducer<Record<string, string[]>>({}, builder =>
    builder.addCase(debugInfo, (current, { payload: { label, text } }) => {
        return { ...current, [label]: text.split("\n") };
    })
);

const search = createReducer<{ error?: ApiError }>({}, builder =>
    builder
        .addCase(fetchAxes.fulfilled, (current, action) => ({}))
        .addCase(fetchAxes.rejected, (current, { error }) => {
            if (shouldNotify(error)) {
                return { error: toApiError(error) };
            }
            return current;
        })
);

// note: we really need to create from sourced data ...but no data yet :(
const axes = createReducer<Axes>({ bid: [], ask: [] }, builder =>
    builder
        .addCase(clearAxes, () => {
            return {
                bid: [],
                ask: [],
            };
        })
        .addCase(fetchAxes.fulfilled, (current, { payload: axes }) => axes)
        .addCase(insertAxe, (current, { payload: axe }) => {
            if (axe.side === "Bid") {
                return {
                    ...current,
                    bid: [...current.bid, axe],
                };
            }
            if (axe.side === "Ask") {
                return {
                    ...current,
                    ask: [...current.ask, axe],
                };
            }
        })
        .addCase(expireAxe, (current, { payload: axeId }) => {
            let filtered = current.bid.filter(({ id }) => id !== axeId);
            if (filtered.length !== current.bid.length) {
                return {
                    ...current,
                    bid: filtered,
                };
            }
            filtered = current.ask.filter(({ id }) => id !== axeId);
            if (filtered.length !== current.ask.length) {
                return {
                    ...current,
                    ask: filtered,
                };
            }
        })
);

const settings = createReducer<Settings>(loadFromLocalStorage(), builder =>
    builder
        .addCase(loadSettings, (current, { payload: settings }) => settings)
        .addCase(saveSettings.fulfilled, (current, { payload: settings }) => settings)
        .addCase(openSettings, settings => ({
            ...settings,
            isOpened: true,
        }))
        .addCase(closeSettings, settings => ({
            ...settings,
            isOpened: false,
        }))
        .addCase(setColumns, (settings, { payload }) => ({
            ...settings,
            columns: payload,
        }))
        .addCase(clearSort, settings => ({
            ...settings,
            columns: settings.columns.map(column => ({ ...column, sort: undefined })),
        }))
        .addCase(applySort, (settings, { payload: { field, value } }) => {
            const sortIndex = settings.columns.findIndex(column => column.field === field)!;
            return {
                ...settings,
                columns: settings.columns.map((column, index) => {
                    return {
                        ...column,
                        sort: index === sortIndex ? value : undefined,
                    };
                }),
            };
        })
);

export const rootReducer = combineReducers({
    alerts,
    axes,
    brokerDetails,
    debug,
    filters,
    liquidityScore,
    orderMetrics,
    orderSummary,
    search,
    settings,
});

import { createAction, createAsyncThunk } from "@reduxjs/toolkit";
import { OrderMetrics, OrderSummary } from "../models/order";
import { queryBrokerDetails } from "../api/brokersApi";
import { queryOrderSummary } from "../api/orderSummaryApi";
import { getAxesByAssetId } from "../api/axeApi";
import { getLiquidityScoreData, LiquidityScoreParams } from "../api/liquidityApi";
import { getTcaOrderMetrics } from "../api/tcaOrderMetricsApi";
import { Axe, AxeColumn, Axes, AxeSort, AxeType, remainingTime, shouldExpire } from "../models/axe";
import { Quantity } from "../utils";
import { DEFAULT_SETTINGS, loadFromLocalStorage, saveToLocalStorage, Settings } from "../models/settings";
import { AppState } from "./store";
import { Alert } from "../models/alerts";
import { BrokerDetails } from "../models/brokers";

export const fetchOrderSummary = createAsyncThunk<OrderSummary, number>("FETCH_ORDER_SUMMARY", async orderNumber => {
    return queryOrderSummary(orderNumber);
});

export const clearOrder = createAction("CLEAR_ORDER");

export const fetchBrokerDetails = createAsyncThunk<BrokerDetails, number>(
    "FETCH_RESTRICTED_BROKERS",
    async orderNumber => {
        return await queryBrokerDetails(orderNumber);
    }
);

type LiquidityScore = number | null;

export const fetchLiquidityScoreData = createAsyncThunk<LiquidityScore, LiquidityScoreParams>(
    "FETCH_LIQUIDITY_SCORE",
    async (params: LiquidityScoreParams) => {
        return params.cusip ? getLiquidityScoreData(params) : null;
    }
);

export const fetchOrderMetrics = createAsyncThunk<OrderMetrics, number>("FETCH_ORDER_METRICS", getTcaOrderMetrics);

export const clearAxes = createAction("CLEAR_AXES");

/**
 * TODO: Fix this hack by making the axe expiry part of a proper flow... it's all ag-fucking-grid fault!
 */
const dispatch = function () {
    // @ts-ignore
    window.store.dispatch.apply(this, arguments);
} as any;

export const fetchAxes = createAsyncThunk<Axes, string>("FETCH_AXES", async assetId => {
    const axes = await getAxesByAssetId(assetId);
    axes.bid.forEach(axe => {
        if (shouldExpire(axe)) {
            setTimeout(() => dispatch(expireAxe(axe.id)), remainingTime(axe));
        }
    });
    axes.ask.forEach(axe => {
        if (shouldExpire(axe)) {
            setTimeout(() => dispatch(expireAxe(axe.id)), remainingTime(axe));
        }
    });
    return axes;
});

export const setColumns = createAction("SET_COLUMNS", function (columns: AxeColumn[]) {
    return { payload: columns };
});

export const filterMinSize = createAction("FILTER_MINSIZE", function (size: Quantity) {
    return { payload: size };
});

export const filterSource = createAction("FILTER_SOURCE", function (sources: AxeType[]) {
    return { payload: new Set(sources) };
});

export const filterLimit = createAction("FILTER_LIMIT", function (limit: boolean) {
    return { payload: limit };
});

export const filterRestricted = createAction("FILTER_RESTRICTED", function (restricted: boolean) {
    return { payload: restricted };
});

export const loadSettings = createAction("LOAD_SETTINGS", function () {
    return { payload: loadFromLocalStorage() ?? DEFAULT_SETTINGS };
});

export const saveSettings = createAsyncThunk("SAVE_SETTINGS", async (override: Partial<Settings>, { getState }) => {
    const state = getState() as AppState;
    const settings: Settings = { ...state.settings, ...override };
    saveToLocalStorage(settings);
    return settings;
});

export const openSettings = createAction("OPEN_SETTINGS");

export const closeSettings = createAction("CLOSE_SETTINGS");

export const insertAxe = createAction("INSERT_AXE", function (axe: Axe) {
    if (shouldExpire(axe)) {
        setTimeout(() => dispatch(expireAxe(axe.id)), remainingTime(axe));
    }
    return { payload: axe };
});

export const expireAxe = createAction("EXPIRE_AXE", function (axeId: string) {
    return { payload: axeId };
});

export const applySort = createAction("APPLY_SORT", function (field: keyof Axe | "auto", value: AxeSort) {
    return { payload: { field, value } };
});

export const clearSort = createAction("CLEAR_SORT");

export const debugInfo = createAction("DEBUG_INFO", function (label: string, text: string) {
    return { payload: { label, text } };
});

export const notifyAlert = createAction("NOTIFY_ALERT", function (alert: Alert) {
    return { payload: alert };
});

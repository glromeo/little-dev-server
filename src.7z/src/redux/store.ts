import { configureStore } from "@reduxjs/toolkit";
import thunk from "redux-thunk";
import { createLogger } from "redux-logger";
import { rootReducer } from "./reducers";

import { enableMapSet } from "immer";

enableMapSet();

export type AppState = ReturnType<typeof rootReducer>;

// NOTE: logger must be the last middleware in the chain

const loggerOptions = {
    collapsed: (getState: any, action: any, logEntry: any) => !logEntry.error,
};

const middleware = /logger=true/.test(window.location.search) ? [thunk, createLogger(loggerOptions)] : [thunk];

// When we are running in Cypress or JCEF/Dashboard we have initialState, otherwise it will be undefined -> empty

export const store = configureStore({
    reducer: rootReducer,
    middleware: middleware,
    preloadedState: (window as any).initialState || {},
});

// Expose the store so that it can be accessed by Cypress or JCEF/Dashboard
(window as any).store = store;

import { BrowserRouter as Router } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./redux/store";

import "./app.css";

type Props = {
    children: JSX.Element;
};

const App = ({ children }: Props) => {
    return (
        <div className="App">
            <Router basename="/apps/market-depth">
                <Provider store={store}>{children}</Provider>
            </Router>
        </div>
    );
};

export default App;

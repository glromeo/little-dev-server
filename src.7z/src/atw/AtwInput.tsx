import React, {ReactChild} from "react";

export type AtwInputProps = {
    disabled?: boolean
    isValid: (value: string) => boolean
    format: (value: string) => string
    value?: string
    onChange?: (value: string) => void
}

export function AtwInput({disabled, value, format, onChange}: AtwInputProps) {
    // @ts-ignore
    return <input disabled={disabled} value={value}/>
}
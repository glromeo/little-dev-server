import React, {ReactChild} from "react";

export type AtwToggleProps = {
    disabled?: boolean
    value: string | null
    options: string[]
    onChange?: (value: string | null) => void
}

export function AtwToggle({disabled, value, options, onChange}: AtwToggleProps) {
    // @ts-ignore
    return <div disabled={disabled}/>
}
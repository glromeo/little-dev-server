import "./AtwColumnResizer.scss";
import {useCallback, useState} from "react";

type ColumnResizerProps = { width: number, onResize: (width: number) => void };

let af:any;

export function AtwColumnResizer({width, onResize}: ColumnResizerProps) {
    const onMouseDown = useCallback(function (trigger) {

        trigger.preventDefault();
        trigger.stopPropagation();

        document.body.addEventListener("mousemove", dragHandler);
        document.body.addEventListener("mouseup", dragHandler);

        const initialX = trigger.pageX;

        function dragHandler(drag: MouseEvent) {
            if (drag.buttons !== 1) {
                requestAnimationFrame(function () {
                    document.body.removeEventListener("mousemove", dragHandler);
                    document.body.removeEventListener("mouseup", dragHandler);
                });
            } else {
                const deltaX = drag.pageX - initialX;
                af = requestAnimationFrame(function () {
                    cancelAnimationFrame(af);
                    onResize(width + deltaX);
                });
            }
        }
    }, [onResize]);
    return (
        <div className="resizer" onMouseDown={onMouseDown} onClickCapture={e => {
            e.preventDefault();
            e.stopPropagation();
        }}/>
    )
}
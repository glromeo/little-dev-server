import React, { ReactNode, useCallback } from "react";
import ReactDOM from "react-dom";

import "./atwTooltip.scss";

export type AtwTooltipProps = React.AllHTMLAttributes<any> & {
    message: string | null;
    children: ReactNode;
};

export function AtwTooltip({ message, children, ...rest }: AtwTooltipProps) {
    const tooltipElement = document.getElementById("tooltip")!;

    const onPointerEnter = useCallback(
        ({ pageX, pageY }) => {
            if (message) {
                let left = pageX > window.innerWidth * 0.75;
                let top = pageY > window.innerHeight * 0.75;
                ReactDOM.render(
                    <div className={`content ${left ? "left" : "right"} ${top ? "top" : "bottom"}`}>{message}</div>,
                    tooltipElement
                );
                tooltipElement.classList.add("visible");
                tooltipElement.style.left = `${pageX}px`;
                tooltipElement.style.top = `${pageY}px`;
            }
        },
        [message, tooltipElement]
    );

    const onPointerLeave = useCallback(() => {
        tooltipElement.classList.remove("visible");
    }, [tooltipElement]);

    return (
        <div onPointerEnter={onPointerEnter} onPointerLeave={onPointerLeave} {...rest}>
            {children}
        </div>
    );
}

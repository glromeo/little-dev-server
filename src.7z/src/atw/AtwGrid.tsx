import React, {CSSProperties, useLayoutEffect, useMemo, useRef, useState} from 'react';
import './AtwGrid.scss';
import {AtwColumnResizer} from "./AtwColumnResizer";
import {ArrowUp} from "./icons/ArrowUp";
import {ArrowDown} from "./icons/ArrowDown";

export type AtwColumnDef = {
    label: string;
    field: string;
    type: any;
    width: number;
    className: string;
    sort: "asc" | "desc" | null;
    style: CSSProperties | null;
};

const TEXT_ALIGN: any = {
    "0": "center",
    "1": "left",
    "2": "right"
}

export type AtwRowDef = CSSProperties & {
    height: number;
};

function totalWidth(columnDefs: AtwColumnDef[]) {
    return columnDefs.reduce((scrollWidth, {width}) => scrollWidth + width, 0);
}

function totalHeight(rowStyles: AtwRowDef[]) {
    return rowStyles.reduce((scrollHeight, {height}) => scrollHeight + height, 0);
}

export type AtwGridProps = {
    columnDefs: AtwColumnDef[]
    onChange: (changed: { columnDefs: AtwColumnDef[] }) => void
}

export function AtwGrid({columnDefs, onChange}: AtwGridProps) {

    const ROW_HEIGHT = 32;
    const headerHeight = ROW_HEIGHT;

    const [rowStyles, setRowStyles] = useState<AtwRowDef[]>(() => [
        ...new Array(100).fill(0).map((rowData: any, index: number) => ({
            transform: `translateY(${index ? ROW_HEIGHT / 2 + index * ROW_HEIGHT : 0}px)`,
            height: index ? ROW_HEIGHT : ROW_HEIGHT * 1.5,
            background: "white"
        }))
    ]);

    const [scrollWidth, setScrollWidth] = useState(() => totalWidth(columnDefs));
    const [scrollHeight, setScrollHeight] = useState(() => totalHeight(rowStyles));

    const tableData = useMemo(() => {
        const data: any[] = new Array(rowStyles.length);
        for (let rowIndex = 0; rowIndex < data.length; rowIndex++) {
            data[rowIndex] = {};
            for (let columnIndex = 0; columnIndex < columnDefs.length; columnIndex++) {
                let num = 10 * (Math.random() * 10);
                data[rowIndex][columnDefs[columnIndex].field] = Number(num.toFixed(0));
            }
        }
        return data;
    }, []);

    const tableRef = useRef<HTMLTableElement>(null);

    useLayoutEffect(() => {
        const table = tableRef.current;
    }, [tableRef])

    function toggleSort(target: AtwColumnDef) {
        const sort = target.sort === null ? "asc" : target.sort === "asc" ? "desc" : null;
        onChange({
            columnDefs: columnDefs.map(columnDef => {
                return {
                    ...columnDef,
                    sort: columnDef === target ? sort : null
                };
            })
        });
        if (sort) {
            const mapped: { index: number, value: any }[] = tableData.map((rowData, index) => ({
                index,
                value: rowData[target.field]
            })).sort(sort === "asc"
                ? ({value: l}, {value: r}) => l === r ? 0 : l < r ? -1 : 1
                : ({value: l}, {value: r}) => l === r ? 0 : l < r ? 1 : -1
            );
            let bucket = 0, buckets = 0, last: any = null;
            for (const {value} of mapped) if (value !== last) {
                buckets++;
                last = value;
            }
            last = mapped[0].value;
            setRowStyles(mapped.reduce(function (arr, m, index) {
                if (last !== m.value) {
                    last = m.value;
                    bucket++;
                }
                arr[m.index] = {
                    transform: `translateY(${index ? ROW_HEIGHT / 2 + index * ROW_HEIGHT : 0}px)`,
                    height: index ? ROW_HEIGHT : ROW_HEIGHT * 1.5,
                    background: `rgba(216, 48, 12, ${1 - bucket / buckets})`
                };
                return arr;
            }, new Array<AtwRowDef>(mapped.length)))
        } else {
            setRowStyles(tableData.map((_, index) => ({
                transform: `translateY(${index ? ROW_HEIGHT / 2 + index * ROW_HEIGHT : 0}px)`,
                height: index ? ROW_HEIGHT : ROW_HEIGHT * 1.5,
                background: "white"
            })))
        }
    }

    function updateColumnDef(columnDef: AtwColumnDef, update: Partial<AtwColumnDef>) {
        const newColumnDefs = columnDefs.map(c => {
            return c === columnDef ? {...c, ...update} : c;
        });
        onChange({
            columnDefs: newColumnDefs
        });
        if ("width" in update) {
            setScrollWidth(totalWidth(newColumnDefs));
        }
    }

    return (
        <div className="AtwGrid">
            <div className="table" ref={tableRef}>
                <div className="thead" style={{width: scrollWidth, height: headerHeight}}>
                    <div className="tr">
                        {columnDefs.map((columnDef, columnIndex) => {
                            const {className, width, sort} = columnDef;
                            const style: CSSProperties = {
                                width: `${width}px`,
                                height: `${headerHeight}px`
                            }
                            return (
                                <div className={`th ${className}`} key={columnDef.field} style={style}
                                     onClick={() => toggleSort(columnDef)}>
                                    {columnDef.label}
                                    {sort === "asc" ? <ArrowUp/> : sort === "desc" ? <ArrowDown/> : null}
                                    <AtwColumnResizer width={columnDef.width}
                                                      onResize={width => updateColumnDef(columnDef, {width})}/>
                                </div>
                            );
                        })}
                    </div>
                </div>
                <div className="tbody" style={{paddingTop: headerHeight, width: scrollWidth, height: scrollHeight}}>{
                    tableData.map((rowData, rowIndex) => {
                        const rowStyle = rowStyles[rowIndex];
                        return (
                            <div className="tr" key={rowIndex} style={rowStyle}>{
                                columnDefs.map((columnDef, columnIndex) => {
                                    const {className, width} = columnDef;
                                    const style: CSSProperties = {
                                        width: `${width}px`,
                                        height: rowStyle.height
                                    }
                                    return (
                                        <div className={`td ${className}`} key={columnIndex} style={style}>
                                            {rowData[columnDef.field]}
                                        </div>
                                    );
                                })
                            }</div>
                        );
                    })
                }</div>
            </div>
        </div>
    );
}

export default AtwGrid;

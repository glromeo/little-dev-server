import React, {ReactChild} from "react";

export type AtwCheckboxProps = {
    disabled?: boolean
    checked: boolean | null
    onChange?: (checked: boolean) => void
    children: ReactChild | ReactChild[]
}

export function AtwCheckbox({disabled, checked, onChange, children}: AtwCheckboxProps) {
    // @ts-ignore
    return <div disabled={disabled}>{children}</div>
}
import { Axe, AxeSide, AxeSort } from "./axe";

type SortField = keyof Axe;

export const selections: Partial<Record<SortField, SortField[]>> = {
    price: ["price", "createTime", "size", "source", "type"],
    spread: ["spread", "createTime", "size", "source", "type"],
};

type SortDir = -1 | 0 | 1;

export type AxeComparator = (l: Axe, r: Axe) => SortDir;

export function axesComparator(
    side: AxeSide,
    sort: AxeSort,
    field: keyof Axe,
    auto: "price" | "spread"
): AxeComparator {
    const fields = selections[field] ?? [field, ...selections[auto]!];

    let up: SortDir = sort === "asc" ? 1 : -1;
    let down: SortDir = sort === "asc" ? -1 : 1;

    if (side === "Bid" && (field === "price" || field === "spread")) {
        up = -up as SortDir;
        down = -down as SortDir;
    }

    return (l: Axe, r: Axe) => {
        for (const field of fields) {
            if (field === "price" || field === "spread" || field === "size") {
                if (!l[field] && r[field]) return 1;
                if (!r[field] && l[field]) return -1;
            } else {
                if (l[field] === null && r[field] !== null) return down;
                if (r[field] === null && l[field] !== null) return up;
            }
            if (l[field]! < r[field]!) return down;
            if (l[field]! > r[field]!) return up;
        }
        return 0;
    };
}

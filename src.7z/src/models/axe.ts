export type AxeSide = "Ask" | "Bid";

export type AxeType = "AXE" | "ECN" | "IND" | null;

export type AxeExpiryType = "GOOD_TILL_DAY" | "GOOD_TILL_CANCELLED" | "GOOD_TILL_TIME";

export type Axes = {
    bid: Axe[];
    ask: Axe[];
    error?: string;
};

export type Axe = {
    // defaults
    id: string;
    side: AxeSide | undefined;
    type: AxeType;
    size: number;
    createTime: Date | null;
    source: string;
    // non- defaults
    actionableFlag: boolean;
    assetId: string;
    axeSubtype: string;
    axeType: string | undefined;
    benchmarkAssetId: string;
    benchmarkSecurityId: string;
    benchmarkSecurityIdType: string | undefined;
    brokerCode: number;
    brokerCode2: number;
    brokerName: string;
    creator: string;
    displaySize: string;
    ecnAxeId: string;
    effectiveUtcDate: string;
    effectiveTime: Date | null;
    expiryTime: number | null;
    expiryType: AxeExpiryType | undefined;
    externalAxeId: string;
    hedgeAssetId: string;
    hedgeAssetIdType: string | undefined;
    internalComment: string;
    marketYield: number;
    marketYieldType: string | undefined;
    minimumSize: number;
    modifier: string;
    modifyTime: Date | null;
    naturalFlag: true;
    orderNumber: number;
    originalSource: string;
    previousEcnAxeId: string;
    price: number;
    priceCurrencyCode: string;
    priceType: string | undefined;
    qualifier: string;
    quality: string;
    qualityScore: number;
    riskKey: number;
    scope: string;
    securityId: string;
    securityIdType: string | undefined;
    settleTime: Date | null;
    sourceComment: string;
    speed: number;
    speedUnits: string;
    spotOption: string;
    spread: number;
    status: string;
    submitter: string;
    touchCount: number;
    tradedPrice: number;
    transactionType: string | undefined;
};

export type AxeFieldType =
    | "auto"
    | "action"
    | "number"
    | "price"
    | "spread"
    | "size"
    | "source"
    | "time"
    | "text"
    | "boolean"
    | "timer";

export type AxeSort = "asc" | "desc";

/**
 * NOTES:
 *
 * SORT - Use a custom comparator instead of AgGrid's sort order, otherwise AgGrid
 *         is showing the arrows in more than one column making the UI more cluttered.
 *        It also makes simpler to define sort ordering changing when the main column changes
 */

export type AxeColumn = {
    type: AxeFieldType; // One of the normalized axe types
    field: keyof Axe | "auto"; // The field from the underlying axe to render in each row
    name: string; // The name to show in the picker
    sort?: AxeSort; // If not undefined specifies to sort the rows according to the column data
    order: number; // Column ordering for both the grid and the picker
    required: boolean; // Show the column as required in the picker
    hidden?: boolean; // To hide a column from the UI
    width?: number; // This is the persistent (local storage) width of the column
    pinned?: boolean; // If true makes the column sticking to the left/right side (ask/bid)
    tooltip?: string; // tooltip display in picker
};

export type AxeColumns = {
    bid: AxeColumn[];
    ask: AxeColumn[];
};

export function columnLabel(side: AxeSide, { name }: AxeColumn): string {
    switch (name) {
        case "Auto":
            return side;
        case "Size":
            return `${side}\nSize`;
        case "Source":
            return `${side} Source`;
    }
    return name;
}

// NOTE: FOR NOW JAMES **ONLY** WANTS THE COLUMSN BELOW ... personally I think there are some good fields in there ...but oh well...comment out for now ...
export const ALL_AXE_COLUMNS: AxeColumn[] = [
    // defaults
    {
        type: "action",
        field: "type",
        name: "Type",
        order: 0,
        required: true,
        pinned: true,
    },
    {
        type: "number",
        field: "id",
        name: "Id",
        order: 1,
        required: true,
        hidden: true,
    },
    {
        type: "auto",
        field: "auto",
        name: "Auto",
        order: 2,
        required: true,
    },
    {
        type: "size",
        field: "size",
        name: "Size",
        order: 3,
        required: true,
    },
    {
        type: "time",
        field: "createTime",
        name: "Time In",
        order: 4,
        required: true,
    },
    {
        type: "source",
        field: "brokerName",
        name: "Source",
        order: 5,
        required: true,
    },
    // non-defaults (please keep alphabetical - based on field NAME)
    {
        type: "boolean",
        field: "naturalFlag",
        name: "Natural Flag",
        order: 6,
        required: false,
    },
    {
        type: "price",
        field: "price",
        name: "Price",
        order: 7,
        required: false,
    },
    {
        type: "text",
        field: "quality",
        name: "Quality",
        order: 8,
        required: false,
    },
    {
        type: "spread",
        field: "spread",
        name: "Spread",
        order: 9,
        required: false,
    },
    {
        type: "timer",
        field: "expiryTime",
        name: "Time Left",
        order: 10,
        required: false,
    },
    {
        type: "number",
        field: "marketYield",
        name: "Yield",
        order: 11,
        required: false,
    },
    // {
    //     type: "boolean",
    //     field: "actionableFlag",
    //     name: "Actionable",
    //     order: 6,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "size",
    //     name: "Actual Size",
    //     order: 7,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "assetId",
    //     name: "Asset Id",
    //     order: 8,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "axeSubtype",
    //     name: "Sub Type",
    //     order: 9,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "benchmarkAssetId",
    //     name: "Benchmark Asset Id",
    //     order: 10,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "benchmarkSecurityId",
    //     name: "Benchmark Security Id",
    //     order: 11,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "benchmarkSecurityIdType",
    //     name: "Benchmark Security Id Type",
    //     order: 12,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "brokerCode",
    //     name: "Broker Code",
    //     order: 13,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "brokerCode2",
    //     name: "Broker Code 2",
    //     order: 14,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "brokerName",
    //     name: "Broker Name",
    //     order: 15,
    //     required: false,
    // },
    // {
    //     type: "time",
    //     field: "createTime",
    //     name: "Create Time",
    //     order: 16,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "creator",
    //     name: "Creator",
    //     order: 17,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "displaySize",
    //     name: "Display Size",
    //     order: 18,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "ecnAxeId",
    //     name: "Ecn Axe Id",
    //     order: 19,
    //     required: false,
    // },
    // {
    //     type: "time",
    //     field: "effectiveTime",
    //     name: "Effective Time",
    //     order: 20,
    //     required: false,
    // },
    // {
    //     type: "time",
    //     field: "effectiveUtcDate",
    //     name: "Effective Utc Date",
    //     order: 21,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "expiryType",
    //     name: "Expiry Type",
    //     order: 23,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "externalAxeId",
    //     name: "External Axe Id",
    //     order: 24,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "hedgeAssetId",
    //     name: "Hedge Asset Id",
    //     order: 25,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "hedgeAssetIdType",
    //     name: "Hedge Asset Id Type",
    //     order: 26,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "internalComment",
    //     name: "Internal Comment",
    //     order: 27,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "marketYieldType",
    //     name: "Market Yield Type",
    //     order: 29,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "minimumSize",
    //     name: "Minimum Size",
    //     order: 30,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "modifier",
    //     name: "Modifier",
    //     order: 31,
    //     required: false,
    // },
    // {
    //     type: "time",
    //     field: "modifyTime",
    //     name: "Modify Time",
    //     order: 32,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "orderNumber",
    //     name: "Order Number",
    //     order: 34,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "originalSource",
    //     name: "Original Source",
    //     order: 35,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "previousEcnAxeId",
    //     name: "Previous Ecn Axe Id",
    //     order: 36,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "priceCurrencyCode",
    //     name: "Price Currency Code",
    //     order: 37,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "priceType",
    //     name: "Price Type",
    //     order: 38,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "qualifier",
    //     name: "Qualifier",
    //     order: 39,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "qualityScore",
    //     name: "Quality Score",
    //     order: 41,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "riskKey",
    //     name: "Risk Key",
    //     order: 42,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "scope",
    //     name: "Scope",
    //     order: 43,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "securityId",
    //     name: "Security Id",
    //     order: 44,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "securityIdType",
    //     name: "Security Id Type",
    //     order: 45,
    //     required: false,
    // },
    // {
    //     type: "time",
    //     field: "settleTime",
    //     name: "Settle Time",
    //     order: 46,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "sourceComment",
    //     name: "Source Comment",
    //     order: 47,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "speed",
    //     name: "Speed",
    //     order: 48,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "speedUnits",
    //     name: "Speed Units",
    //     order: 49,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "spotOption",
    //     name: "Spot Option",
    //     order: 50,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "status",
    //     name: "Status",
    //     order: 52,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "submitter",
    //     name: "Submitter",
    //     order: 53,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "touchCount",
    //     name: "Touch Count",
    //     order: 54,
    //     required: false,
    // },
    // {
    //     type: "number",
    //     field: "tradedPrice",
    //     name: "Traded Price",
    //     order: 55,
    //     required: false,
    // },
    // {
    //     type: "text",
    //     field: "transactionType",
    //     name: "Transaction Type",
    //     order: 56,
    //     required: false,
    // },
];

export type SourceType = "Axes" | "Indicative Axes" | "ECNs" | "Runs";

export function shouldExpire(axe: Axe): boolean {
    return axe.type === "ECN" && axe.expiryType === "GOOD_TILL_TIME";
}

export function remainingTime(axe: Axe): number {
    return axe.expiryTime ? Math.max(0, axe.expiryTime - Date.now()) : 0;
}

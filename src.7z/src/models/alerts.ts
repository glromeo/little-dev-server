import { SerializedError } from "@reduxjs/toolkit";

export type AlertType = "ERROR" | "MESSAGE" | "SUCCESS" | "WARNING";

let alertId = 0;

export class Alert {
    id: number;

    constructor(
        public title: string | undefined,
        public message: string,
        public type: AlertType = "MESSAGE",
        public timeout: number = 3600000
    ) {
        this.id = alertId++;
    }
}

export type ApiError = {
    title: string;
    message: string;
};

export function createError(title: string, message: string) {
    return JSON.stringify({ title, message });
}

type GQLError = { message: string; path: string | null; extensions: string | null };

export function gqlError([error]: GQLError[]) {
    return JSON.stringify({ title: "Query Failed", message: error.message });
}

const GENERIC_ERROR: ApiError = {
    title: "Error",
    message: "Failure accessing Aladdin API",
};
export const SUPPRESSED_ERRORS: Set<string | undefined> = new Set(["AbortError"]);

export function toApiError(error: SerializedError): ApiError {
    if ("{" === error.message?.charAt(0)) {
        return error.message ? (JSON.parse(error.message) as ApiError) : GENERIC_ERROR;
    } else {
        return {
            title: "Aladdin API Error",
            message: error.message ?? "Sorry, no message provided :(",
        };
    }
}

export function toAlert(error: SerializedError, type: AlertType = "ERROR"): Alert {
    const { title, message } = toApiError(error);
    return new Alert(title, message, type);
}

export function shouldNotify(error: SerializedError) {
    return !SUPPRESSED_ERRORS.has(error.name);
}

export type AsyncRejection = { error: SerializedError };

import { Axe, AxeSort } from "./axe";

export type BookColor = string | "transparent";

export const BID_COLOR: BookColor = "255,40,37";
export const ASK_COLOR: BookColor = "59,173,248";
export const DISABLED_COLOR: BookColor = "160,160,160";
export const SEARCH_COLOR: BookColor = "transparent";

export function getBuckets(axes: Axe[], field: keyof Axe): Map<any, Axe[]> {
    const buckets = new Map<any, Axe[]>();
    for (const axe of axes) {
        const key = String(axe[field]);
        const bucket = buckets.get(key);
        if (bucket) {
            bucket.push(axe);
        } else {
            buckets.set(key, [axe]);
        }
    }
    return buckets;
}

export function axeShader(color: BookColor, sort: AxeSort | undefined, buckets: Map<any, Axe[]>): (ax: Axe) => Axe {
    const shades = new Map<Axe, string>();

    const range = buckets.size / (document.body.classList.contains("aux-theme-dark") ? 0.75 : 0.9);
    let shade = sort === "asc" ? 1 : buckets.size;
    let dir = sort === "asc" ? 1 : -1;
    for (const bucket of buckets.values()) {
        for (const axe of bucket) {
            if (color === "transparent") {
                shades.set(axe, color);
            } else {
                shades.set(axe, `rgba(${color}, ${shade / range})`);
            }
        }
        shade += dir;
    }
    return axe => ({ ...axe, shade: shades.get(axe) });
}

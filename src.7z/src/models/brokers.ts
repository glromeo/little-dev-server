export type Broker = {
    ticker: string;
    name: string;
    shortName: string;
    code: number;
};

export type BrokerAllocation = {
    broker: Broker;
    eligiblePlacementQuantityAsPct: number;
};

export type BrokerDetails = {
    allocations: BrokerAllocation[];
    entities: Record<string, string>;
};

import { Axe, AxeSide, AxeType } from "./axe";
import { parseQuantity, Quantity } from "../utils";
import { Order } from "./order";

export type Filters = {
    sources: Set<AxeType>;
    minSize: Quantity;
    limit: boolean;
    hideRestricted: boolean;
    restrictedBrokers: Set<number>;
};

export const DEFAULT_FILTERS: Filters = {
    sources: new Set(),
    minSize: "0",
    limit: false,
    hideRestricted: false,
    restrictedBrokers: new Set(),
};

export type AxeFilter = (axe: Axe) => boolean;

export function axeFilter(side: AxeSide, active: boolean, filters: Filters, order: Order | null): AxeFilter {
    const sourceTypes = filters.sources;
    const minSizeValue = parseQuantity(filters.minSize);
    const restrictedBrokers = filters.restrictedBrokers;
    const limit = order?.limitValue ?? null;

    return axe => {
        if (sourceTypes.size && !sourceTypes.has(axe.type)) return false;

        if (minSizeValue > 0 && axe.size < minSizeValue) return false;

        if (filters.hideRestricted && restrictedBrokers.has(axe.brokerCode)) return false;

        if (active && filters.limit && limit !== null) {
            if (side === "Bid") {
                if (axe.price > limit) return false;
            } else {
                if (axe.price < limit) return false;
            }
        }

        return true;
    };
}

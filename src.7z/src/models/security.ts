export type BondQualityType = "HY" | "IG";

export type Security = {
    assetId: string;
    cusip: string;
    isin: string;
    ticker: string;
    couponValue: number;
    maturity: string; // DD-MMM-YYYY
    bondQuality: BondQualityType;
};

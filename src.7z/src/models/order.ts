import { Security } from "./security";

export type OrderSide = "Buy" | "Sell";

export type Order = {
    ordNum: number; // ordNum
    side: OrderSide; // effectiveTranType
    unbookedAmount: number;
    limitValue: number; // limitValue
    priceCurrency: string; // priceCurrency
    orderLeaves: number | null;
    percentBooked: number | null; // TO BE FIXED
};

export type OrderSummary = {
    order: Order | null;
    orderNumber: number | null;
    security: Security | null;
};

export type OrderMetrics = {
    expectedCost?: number;
    expectedCostBps?: number;
    advForecast?: number;
    advForecastPct?: number;
};

// no clue what this is yet - use this is a typed placedholder...until we get more info...
import { ALL_AXE_COLUMNS, AxeColumn } from "./axe";
import { mutateHost, queryHost } from "../utils";
import { store } from "../redux/store";
import { saveSettings } from "../redux/actions";

export type CompositePrices = string[];

export type Settings = {
    version: string;
    isOpened: boolean;
    columns: AxeColumn[];
    compositePrices: CompositePrices;
};

// TODO : remove expiry time from the defaults !!!
const DEFAULT_COLUMNS: AxeColumn[] = [...ALL_AXE_COLUMNS.slice(0, 6)];

// who the hell knows where this data is coming from (I think dashboard??) - hard code with defaults for now ...
const DEFAULT_COMPOSITE_PRICES: CompositePrices = ["Triton", "CEP", "CP+"];

export const DEFAULT_SETTINGS: Settings = {
    version: "0.1.0",
    isOpened: false,
    columns: DEFAULT_COLUMNS,
    compositePrices: DEFAULT_COMPOSITE_PRICES,
};

export function loadFromLocalStorage(): Settings {
    const stored = localStorage.getItem("settings");
    if (stored) {
        try {
            return JSON.parse(stored) as Settings;
        } catch (e) {
            localStorage.setItem("settings", JSON.stringify(DEFAULT_SETTINGS));
            return DEFAULT_SETTINGS;
        }
    } else {
        localStorage.setItem("settings", JSON.stringify(DEFAULT_SETTINGS));
        queryHost<Settings>("/settings").then((saved: any) => {
            store.dispatch(
                saveSettings({
                    ...DEFAULT_SETTINGS,
                    columns:
                        saved?.columns?.map(({ field, order, pinned }: Partial<AxeColumn>) => {
                            const column = ALL_AXE_COLUMNS.find(column => field === column.field);
                            return {
                                ...column,
                                order,
                                pinned,
                            } as AxeColumn;
                        }) ?? DEFAULT_COLUMNS,
                    compositePrices: saved?.priceSources ?? DEFAULT_COMPOSITE_PRICES,
                }) as any
            );
        });
    }
    return DEFAULT_SETTINGS;
}

export function saveToLocalStorage(settings: Settings): void {
    localStorage.setItem("settings", JSON.stringify(settings));
    mutateHost<any>("/settings", {
        columns: settings.columns.map(column => ({
            field: column.field,
            order: column.order,
            pinned: column.pinned,
        })),
        priceSources: settings.compositePrices,
    });
}

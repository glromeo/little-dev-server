import { Axe, AxeSort } from "../models/axe";
import { useEffect, useState } from "react";

type Section = {
    buckets: Map<any, Axe[]>;
    sort: {
        field: keyof Axe;
        dir: AxeSort;
    };
};

export type PriceSource = "Triton";
export type PriceRecords = Record<PriceSource, number>;
export type CompositePrices = { bid: PriceRecords; ask: PriceRecords };

const NO_PRICES = { bid: { Triton: 0 }, ask: { Triton: 0 } };

export function usePrices(min: [number, number], max: [number, number]): CompositePrices {
    const [prices, setPrices] = useState<CompositePrices>(NO_PRICES);
    useEffect(
        function () {
            const interval = setInterval(function () {
                setPrices({
                    bid: { Triton: min[0] + Math.random() * (max[0] - min[0]) },
                    ask: { Triton: min[1] + Math.random() * (max[1] - min[1]) },
                });
            }, 1000);
            return function () {
                clearTimeout(interval);
            };
        },
        [min, max]
    );
    return prices;
}

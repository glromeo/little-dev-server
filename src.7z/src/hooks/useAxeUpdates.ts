import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { expireAxe, insertAxe, notifyAlert } from "../redux/actions";
import { Alert } from "../models/alerts";
import { acceptRawAxe, mapRawAxe, RawAxe } from "../api/axeApi";
import { recording } from "../rec";

export function useAxeUpdates(assetId?: string) {
    const dispatch = useDispatch();

    const [socket, setSocket] = useState<WebSocket | null>(null);

    useEffect(() => {
        let host = /&ws=([^&]+)/.exec(window.location.search)?.[1] ?? "none";

        if (host === "none") {
            return;
        }
        if (host === "local") {
            host = "ws://localhost:8080";
        } else
            switch (host) {
                case "dev":
                    host = `wss://dev.blackrock.com`;
                    break;
                case "tst":
                    host = `wss://tst.blackrock.com`;
                    break;
                case "prod":
                    host = `wss://webster.bfm.com`;
                    break;
                default:
                    host = `wss://${host}`;
            }

        const socket = new WebSocket(`${host}/marketdepth/stream`);

        socket.onopen = function (e) {
            console.log("connection established");
            setSocket(socket);
            if (recording) {
                recording.onopen();
            }
        };

        socket.onmessage = function (event) {
            const { command, payload } = JSON.parse(event.data);
            switch (command) {
                case "ping":
                    console.log("ping");
                    socket.send(JSON.stringify({ command: "pong" }));
                    return;
                case "expire":
                    const axeId: string = payload;
                    // console.log("expire", axeId);
                    dispatch(expireAxe(axeId));
                    return;
                case "insert":
                    const axe: RawAxe = payload;
                    if (acceptRawAxe(axe)) {
                        // console.log("insert", axe);
                        dispatch(insertAxe(mapRawAxe(axe)));
                    } else {
                        // console.log("ignored", axe);
                    }
                    return;
            }
        };

        socket.onclose = function (event: CloseEvent) {
            if (event.wasClean) {
                dispatch(notifyAlert(new Alert("Streaming", `Connection closed: ${event.reason}`, "MESSAGE", 5000)));
            } else {
                // e.g. server process killed or network down event.code is usually 1006 in this case
                dispatch(notifyAlert(new Alert("Streaming Error", "Connection failed", "MESSAGE", 3000)));
            }
        };

        socket.onerror = function (error: Event) {
            // dispatch(notifyAlert(new Alert("Streaming Error", (error as any).message)));
        };

        return function () {
            socket.close(1000, "unmount");
            setSocket(null);
        };
    }, [dispatch]);

    useEffect(() => {
        if (socket && assetId) {
            console.log("streaming updates for asset:", assetId);
            socket.send(
                JSON.stringify({
                    command: "subscribe",
                    payload: assetId,
                })
            );
        }
    }, [socket, assetId]);
}

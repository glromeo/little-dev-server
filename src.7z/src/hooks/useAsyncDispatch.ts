import { useDispatch } from "react-redux";
import { useCallback, useEffect, useState } from "react";

export const useAsyncDispatch = () => {
    const dispatch = useDispatch();
    const [requests] = useState<ReturnType<typeof dispatch>[]>([]);

    useEffect(() => () => requests.forEach(request => request.abort?.call()), [requests]);

    return useCallback(
        (func: Function) => {
            const request = dispatch(func);
            requests.push(request);
            return request;
        },
        [dispatch, requests]
    );
};

import { useLocation } from "react-router-dom";
import { useMemo } from "react";

export interface QueryParams {
    assetId: string | null;
    cusip: string | null;
    theme: "light" | "dark";
    embedded: boolean;
    env: string | null;
    user: string | null;
}

export function useQuery(): QueryParams {
    const { search } = useLocation();
    return useMemo(() => {
        return getQuery(search);
    }, [search]);
}

let cachedSearch: String;
let cachedQuery: QueryParams;

export function getQuery(search: string = window.location.search): QueryParams {
    if (cachedSearch === window.location.search) {
        return cachedQuery;
    }
    cachedSearch = window.location.search;
    const query = new URLSearchParams(search);
    return (cachedQuery = {
        assetId: query.get("cusip"),
        cusip: query.get("cusip"),
        embedded: !!query.get("embedded"),
        theme: query.get("theme") === "dark" ? "dark" : "light",
        env: query.get("env"),
        user: query.get("user"),
    });
}

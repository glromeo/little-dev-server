import { Axe, remainingTime, shouldExpire } from "../../models/axe";
import { useEffect, useState } from "react";
import { formatTimer } from "../../utils";

export type ExpiryTimeProps = {
    data: Axe;
};

export function ExpiryTime({ data: axe }: ExpiryTimeProps) {
    const [remainingTimeMs, setRemainingTimeMs] = useState<number | null>(null);
    useEffect(() => {
        if (shouldExpire(axe)) {
            const timeout = setTimeout(() => setRemainingTimeMs(remainingTime(axe)), 1000);
            return () => {
                clearTimeout(timeout);
            };
        }
    }, [axe, remainingTimeMs]);
    if (remainingTimeMs !== null) {
        return formatTimer({ value: remainingTimeMs });
    } else {
        return "";
    }
}

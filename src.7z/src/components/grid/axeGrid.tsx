import {Axe, AxeColumn, AxeFieldType, AxeSide, AxeSort, columnLabel} from "../../models/axe";
import {useCallback, useMemo} from "react";

import "./axe-grid.scss";
import AtwGrid from "../../atw/AtwGrid";
import {useSelector} from "react-redux";
import {AppState} from "../../redux/store";
import {BrokerDetails} from "../../models/brokers";

export type AxeGridChange = {
    side: AxeSide;
    offset?: {
        top: number;
        left: number;
    };
    sort?: {
        field: keyof Axe | "auto";
        value: AxeSort;
    };
};

export type ColumnFormatters = Partial<Record<AxeFieldType, (params: any) => string>>;

export type AxeGridProps = {
    side: AxeSide;
    active: boolean;
    columns: AxeColumn[];
    auto: "price" | "spread";
    data: Axe[];
    formatters: Partial<Record<AxeFieldType, (params: any) => string>>;
    onChange: (change: AxeGridChange) => void;
};


const columnTypes = {
    axeSourceColumn: {
        cellRenderer: "axeSourceCellRenderer",
    },
    axeTypeColumn: {
        cellRenderer: "axeTypeCellRenderer",
    },
    timerColumn: {
        cellRenderer: "timerCellRenderer",
    },
};

function remapSort(side: "Ask" | "Bid", field: string, sort?: AxeSort): AxeSort | undefined {
    if (side === "Bid" && (field === "price" || field === "spread" || field === "auto")) {
        if (sort === "asc") {
            return "desc";
        }
        if (sort === "desc") {
            return "asc";
        }
    }
    return sort;
}

/*
export function AxeGrid({ side, active, columns = [], auto, data = [], formatters = {}, onChange }: AxeGridProps) {
    const [gridApi, setGridApi] = useState<GridApi>();



    const gridOptions = useMemo<AuxGridOptions>(() => {
        let firstRowNode: RowNode; // After each sort this is going to be the first row and that's what has to be taller
        return {
            getRowNodeId: (data: Axe) => data.id,
            defaultColDef: {
                sortable: true,
            },
            getRowHeight: ({ node }: { node: RowNode }) => (node === firstRowNode ? 50 : 25),
            postSort: (nodes: RowNode[]) => (firstRowNode = nodes[0]),
            onSortChanged() {
                const sortState = gridApi!.getSortModel();
                if (sortState.length === 0) {
                    onChange({
                        side,
                        sort: {
                            field: "auto",
                            value: remapSort(side, "auto", "asc" as AxeSort)!,
                        },
                    });
                } else {
                    const { colId, sort } = sortState[0];
                    const field = colId.substr(0, colId.indexOf("_")) || colId;
                    onChange({
                        side,
                        sort: {
                            field: field as keyof Axe,
                            value: remapSort(side, field, sort as AxeSort)!,
                        },
                    });
                }
            },
            alwaysShowVerticalScroll: false,
            scrollbarWidth: 8,
            enableRangeSelection: false,
            enableRangeHandle: false,
            floatingFilter: false,
            floatingFiltersHeight: 0,
            getMainMenuItems: () => [],
            defaultAuxHeaderMenuItems: () => [],
            getRowStyle(params: any) {
                if (params.data) {
                    if (params.node === firstRowNode) {
                        return {
                            background: params.data.shade ?? Theme.gridBackgroundColor,
                            "font-size": "1.2em",
                        };
                    } else {
                        return {
                            background: params.data.shade ?? Theme.gridBackgroundColor,
                        };
                    }
                } else {
                    return {
                        background: Theme.gridBackgroundColor,
                    };
                }
            },
            onGridSizeChanged({ api }) {
                api.sizeColumnsToFit();
            },
            onBodyScroll({ top, left }) {
                onChange({
                    side,
                    offset: {
                        top: Math.max(0, top),
                        left: Math.max(0, left),
                    },
                });
            },

        };
    }, [gridApi, side, onChange]);

}
*/

export function AxeGrid({side, active, columns = [], auto, data = [], formatters = {}, onChange}: AxeGridProps) {
    const brokerDetails = useSelector<AppState, BrokerDetails>(state => state.brokerDetails);
    const columnDefs = useMemo(function () {
        let columnDefs = columns.map(column => ({
            label: columnLabel(side, column),
            width: column.width ?? 50,
            type: column.type,
            field: column.field,
            className: column.pinned ? (side === "Bid" ? "sticky-right" : "sticky-left") : "",
            sort: column.sort ?? null,
            style: null
        }));
        if (side === "Bid") {
            columnDefs.reverse();
        }
        return columnDefs;
    }, [columns, brokerDetails]);
    const changeCallback = useCallback((columnDefs) => onChange({
        side
    }), [side]);
    return <AtwGrid columnDefs={columnDefs} onChange={changeCallback}></AtwGrid>
}
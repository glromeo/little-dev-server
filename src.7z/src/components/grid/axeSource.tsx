import { Axe } from "../../models/axe";
import { store } from "./../../redux/store";

type AxeSourceProps = {
    data: Axe;
};

export function AxeSource({ data: axe }: AxeSourceProps) {
    const state = store.getState();
    const restrictedBrokers = state.filters.restrictedBrokers;
    const brokerEntities = state.brokerDetails.entities ?? {};
    const brokerLabel = brokerEntities[axe.brokerCode] ?? axe.brokerName;
    if (restrictedBrokers.has(axe.brokerCode)) {
        return `${brokerLabel} (!)`;
    } else {
        return brokerLabel;
    }
}

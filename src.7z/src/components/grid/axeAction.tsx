import { Axe } from "../../models/axe";
import { useCallback } from "react";
import { store } from "../../redux/store";
import { openExecution } from "../../api/executionApi";

import "./axe-action.scss";
import { AtwTooltip } from "../../atw/atwTooltip";

export type AxeActionProps = {
    data: Axe;
};

export function AxeAction({ data: axe }: AxeActionProps) {
    const order = store.getState().orderSummary.order!;
    const security = store.getState().orderSummary.security!;
    const restrictedBrokers = store.getState().filters.restrictedBrokers;

    let message: string | null = null;

    if (!order) {
        message = "No order is selected";
    } else if (order.orderLeaves === 0) {
        message = "The order leaves is 0";
    } else if (restrictedBrokers.has(axe.brokerCode)) {
        message = "The broker is fully restricted";
    } else if (!((order.side === "Buy" && axe.side === "Ask") || (order.side === "Sell" && axe.side === "Bid"))) {
        message = "This axe is not in line with the order";
    }

    const active = message === null;

    const onClick = useCallback(() => {
        if (!active) {
            return;
        }
        if (axe.type === "AXE") {
            openExecution({
                axe: {
                    ecnAxeId: axe.ecnAxeId,
                    size: axe.size,
                    price: axe.price,
                    spread: axe.spread,
                    brokerCode: axe.brokerCode,
                    createTime: axe.createTime?.getTime() as any,
                    marketYield: axe.marketYield,
                    marketYieldType: axe.marketYieldType,
                    benchmarkAssetId: axe.benchmarkAssetId,
                },
                order: {
                    ordNum: order.ordNum,
                    unbookedAmount: order.unbookedAmount,
                    side: order.side,
                },
                security: {
                    bondQuality: security.bondQuality,
                },
            });
        } else if (axe.type === "ECN") {
            alert("ECN NOT IMPLEMENTED YET!");
        }
    }, [active, axe, order]);
    if (axe.type) {
        return (
            <AtwTooltip
                className={`axe-action ${axe.type} ${active ? "enabled" : "disabled"}`}
                onClick={onClick}
                message={message}
            >
                {axe.type}
            </AtwTooltip>
        );
    } else {
        return null;
    }
}

import { Route } from "react-router-dom";

import OrderSummary from "./header/orderSummary";
import SearchSummary from "./header/searchSummary";

import DebugInfo from "./debugInfo";

import { AxeGrid, AxeGridChange, ColumnFormatters } from "./grid/axeGrid";
import { useDispatch, useSelector } from "react-redux";
import { AppState } from "../redux/store";
import { Axe, AxeColumn, Axes, AxeSide } from "../models/axe";
import { useCallback, useLayoutEffect, useMemo, useState } from "react";
import { Order, OrderSide } from "../models/order";

import { TitleBar } from "./titleBar";

import "./market-depth.scss";

import { Alert } from "../models/alerts";
import { axeFilter, Filters } from "../models/filtering";
import { axesComparator } from "../models/sorting";
import { Security } from "../models/security";
import { applySort } from "../redux/actions";
import { ASK_COLOR, axeShader, BID_COLOR, getBuckets, SEARCH_COLOR } from "../models/color";
import Rec from "./rec";
import { formatPrice, formatQuantity, formatSpread, formatTime } from "../utils";
import { useAxeUpdates } from "../hooks/useAxeUpdates";
import { usePrices } from "../hooks/usePrices";
import { PriceOverlay } from "./priceOverlay";

export type MarketDepthParams = {
    orderNumber: string;
};

const SIDE_MAPPING: Record<OrderSide, AxeSide> = {
    Sell: "Bid",
    Buy: "Ask",
};

type GridScroll = {
    bid: number;
    ask: number;
};

interface AuxNotificationGroupConfig {
}

const AuxNotificationStyleEnum:any = {};
let AuxNotificationGroupTypeEnum = {TOAST:null};

function AuxNotificationGroup({}:any) {
    return null;
}

export function MarketDepth() {
    const dispatch = useDispatch();

    const axes = useSelector<AppState, Axes>(state => state.axes);
    const columns = useSelector<AppState, AxeColumn[]>(state => state.settings.columns);
    const order = useSelector<AppState, Order | null>(state => state.orderSummary.order);
    const security = useSelector<AppState, Security | null>(state => state.orderSummary.security);
    const filters = useSelector<AppState, Filters>(state => state.filters);

    useAxeUpdates(security?.assetId);

    const isSearchMode = /\/search/.test(window.location.pathname);
    const side: AxeSide | null = isSearchMode ? null : order?.side ? SIDE_MAPPING[order!.side] ?? null : null;

    const auto = security?.bondQuality === "IG" ? "spread" : "price";

    useLayoutEffect(() => {
        if (security) {
            dispatch(applySort("auto", auto === "price" ? "asc" : "desc"));
        }
    }, [dispatch, security, auto]);

    // NOTE: The 3rd state has been removed => There's alway a column with sort!

    const bid = useMemo(() => {
        const bid = axes.bid.filter(axeFilter("Bid", side === "Bid", filters, order));
        let { field, sort } = columns.find(column => column.sort) ?? { field: "auto" };
        if (field === "auto") {
            field = auto;
        }
        if (!sort) {
            sort = field === "price" ? "desc" : "asc";
        }
        bid.sort(axesComparator("Bid", sort, field, auto));
        return {
            axes: bid.map(axeShader(side === "Bid" ? BID_COLOR : SEARCH_COLOR, "desc", getBuckets(bid, field))),
            sort: { field, dir: sort },
        };
    }, [side, columns, axes.bid, order, auto, filters]);

    const ask = useMemo(() => {
        const ask = axes.ask.filter(axeFilter("Ask", side === "Ask", filters, order));
        let { field, sort } = columns.find(column => column.sort) ?? { field: "auto" };
        if (field === "auto") {
            field = auto;
        }
        if (!sort) {
            sort = field === "spread" ? "desc" : "asc";
        }
        ask.sort(axesComparator("Ask", sort, field, auto));
        return {
            axes: ask.map(axeShader(side === "Ask" ? ASK_COLOR : SEARCH_COLOR, "desc", getBuckets(ask, field))),
            sort: { field, dir: sort },
        };
    }, [side, columns, axes.ask, order, auto, filters]);

    const alerts = useSelector<AppState, Alert[]>(state => state.alerts);

    const alertConfig: AuxNotificationGroupConfig[] = useMemo(() => {
        return alerts.map(alert => ({
            id: String(alert.id),
            header: alert.title,
            message: alert.message,
            toastTimeout: alert.timeout,
            notificationStyle: AuxNotificationStyleEnum[alert.type],
        }));
    }, [alerts]);

    const alertClick = useCallback(function (event) {}, []);

    const [scroll, setScroll] = useState<GridScroll>({ bid: 0, ask: 0 });

    const onChange = useCallback(
        ({ side, offset, sort }: AxeGridChange) => {
            if (sort !== undefined) {
                dispatch(applySort(sort.field, sort.value));
            }
            if (offset !== undefined) {
                if (side === "Bid") {
                    setScroll({ bid: offset.top, ask: scroll.ask });
                } else {
                    setScroll({ ask: offset.top, bid: scroll.bid });
                }
            }
        },
        [dispatch, scroll]
    );

    const formatters: ColumnFormatters = useMemo(() => {
        return {
            auto:
                auto === "spread"
                    ? ({ data }: { data: Axe }) => formatSpread({ value: data.spread })
                    : ({ data }: { data: Axe }) => formatPrice({ value: data.price }),
            price: formatPrice,
            spread: formatSpread,
            size: formatQuantity,
            time: formatTime,
        };
    }, [auto]);

    const prices = usePrices(
        ...useMemo<[[number, number], [number, number]]>(() => {
            function minPrice(min: number, axe: Axe): number {
                return Math.min(min, axe.price || min);
            }

            function maxPrice(max: number, axe: Axe): number {
                return Math.max(max, axe.price || max);
            }

            return [
                [bid.axes.reduce(minPrice, Number.MAX_VALUE), ask.axes.reduce(minPrice, Number.MAX_VALUE)],
                [bid.axes.reduce(maxPrice, 0), ask.axes.reduce(maxPrice, 0)],
            ];
        }, [bid, ask])
    );

    return (
        <div className="market-depth">
            <TitleBar />
            <DebugInfo />
            <Rec />
            <AuxNotificationGroup
                type={AuxNotificationGroupTypeEnum.TOAST}
                openOnLoad={true}
                config={alertConfig}
                onNotificationClosed={alertClick}
            />
            <Route path="/search">
                <SearchSummary />
            </Route>
            <Route path="/order/:orderNumber">
                <OrderSummary prices={prices} />
            </Route>
            <div className="main">
                <PriceOverlay side={"Bid"} prices={prices.bid} scroll={scroll.bid} axes={bid.axes} sort={bid.sort}>
                    <AxeGrid
                        side={"Bid"}
                        active={side === "Bid"}
                        columns={columns}
                        auto={auto}
                        data={bid.axes}
                        formatters={formatters}
                        onChange={onChange}
                    />
                </PriceOverlay>
                <PriceOverlay side={"Ask"} prices={prices.ask} scroll={scroll.ask} axes={ask.axes} sort={ask.sort}>
                    <AxeGrid
                        side={"Ask"}
                        active={side === "Ask"}
                        columns={columns}
                        auto={auto}
                        data={ask.axes}
                        formatters={formatters}
                        onChange={onChange}
                    />
                </PriceOverlay>
            </div>
        </div>
    );
}

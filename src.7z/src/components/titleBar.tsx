import React from "react";
import {useQuery} from "../hooks/useQuery";
import {MarketDepthSettings} from "./marketDepthSettings";
import {closeSettings, openSettings} from "../redux/actions";
import {useDispatch, useSelector} from "react-redux";
import {AppState} from "../redux/store";

function AuxWidgetToolbar({}:any) {
    return <div/>;
}

export const TitleBar = React.memo(() => {
    const dispatch = useDispatch();

    const isOpened = useSelector<AppState, boolean>(state => state.settings.isOpened);

    const { embedded } = useQuery();

    return (
        <div style={{ minHeight: embedded ? 0 : 32 }}>
            {!embedded ? (
                <AuxWidgetToolbar
                    role="settings"
                    enableSetting={true}
                    slot="header-toolbar"
                    onSettingsMenuClicked={() => dispatch(openSettings())}
                >Market Depth</AuxWidgetToolbar>
            ) : null}
            {isOpened ? <MarketDepthSettings isOpen={isOpened} onClosed={() => dispatch(closeSettings())} /> : null}
        </div>
    );
});

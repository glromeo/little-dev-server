import React, { useCallback, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import { CompositePrice } from "./settings/compositePrice";
import { ALL_AXE_COLUMNS, AxeColumn } from "../models/axe";
import { AppState } from "../redux/store";
import { saveSettings, setColumns } from "../redux/actions";

interface AuxDialogClosedDetailInterface {
}

type Props = {
    isOpen: boolean;
    onClosed: (event: CustomEvent<AuxDialogClosedDetailInterface>) => void;
};

interface AuxSelectionTreeInterface {
    label: string;
}

function AuxDialog({}:any) {
    return <div/>;
}

function AuxPicklist({}:any) {
    return <div/>;
}

export function MarketDepthSettings({ isOpen, onClosed }: Props) {
    const dispatch = useDispatch();
    const dlgReference = React.useRef(null);
    const ccReference = React.useRef(null);
    const onUpdate = useCallback(() => {
        (ccReference.current as any).getTargetSelection().then((selection: AuxSelectionTreeInterface[]) => {
            // construct new column def order
            const colDefs: AxeColumn[] = [];
            colDefs.push(ALL_AXE_COLUMNS[0]); // type is always at 0
            selection.forEach((element: AuxSelectionTreeInterface) => {
                const item = ALL_AXE_COLUMNS.find(x => x.name === element.label)!;
                colDefs.push(item);
            });
            dispatch(setColumns(colDefs));
            dispatch(saveSettings({ isOpened: false }));
            (dlgReference.current as any).close();
        });
    }, [dispatch]);
    const columns = useSelector<AppState, AxeColumn[]>(state => state.settings.columns);
    const getData = () => {
        const sourceData = ALL_AXE_COLUMNS.filter(
            (column: AxeColumn) => !column.pinned && !column.hidden && !columns.find(x => x.name === column.name)
        ).map((column: AxeColumn) => {
            return {
                label: column.name!,
                tooltip: column.tooltip ?? column.name,
                isDisabled: column.required,
            };
        });
        const targetData = columns
            .filter((column: AxeColumn) => !column.pinned && !column.hidden)
            .map((column: AxeColumn) => {
                return {
                    label: column.name!,
                    tooltip: column.tooltip ?? column.name,
                    isDisabled: column.required,
                };
            });
        return { sourceData, targetData };
    };
    const { sourceData, targetData } = getData();

    const [display, setDisplay] = useState("none");
    const onDialogOpened = useCallback(() => setDisplay("flex"), []);

    return useMemo(
        () => (
            <AuxDialog
                ref={dlgReference}
                role="settings-dlg"
                isOpen={isOpen}
                type="prompt"
                header="Market Depth Settings"
                primaryButtonLabel="Update"
                secondaryButtonLabel="Cancel"
                onDialogOpened={onDialogOpened}
                onDialogClosed={onClosed}
                onSubmitButtonClicked={onUpdate}
            >
                <div className="market-depth-settings" style={{ display }}>
                    <AuxPicklist
                        role="column-chooser"
                        ref={ccReference}
                        className="column-chooser"
                        sourceLabel="Available Columns"
                        targetLabel="Selected Columns"
                        hasAggregator
                        hasDragAndDrop
                        hasReorder
                        allowDuplicates={false}
                        hasSelectedOnly={false}
                        sourceData={sourceData}
                        targetData={targetData}
                    />
                    <CompositePrice />
                </div>
            </AuxDialog>
        ),
        [isOpen, onClosed, onDialogOpened, onUpdate, display, sourceData, targetData]
    );
}

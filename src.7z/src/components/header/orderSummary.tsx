import { ToggleRoute } from "./toggleRoute";
import { Cusip } from "./order/cusip";
import { batch } from "react-redux";
import { useParams } from "react-router-dom";
import { useEffect } from "react";
import {
    fetchAxes,
    fetchBrokerDetails,
    fetchLiquidityScoreData,
    fetchOrderMetrics,
    fetchOrderSummary,
} from "../../redux/actions";
import { MarketDepthParams } from "../marketDepth";
import { SourceType } from "./filters/sourceType";
import { MinSize } from "./filters/minSize";
import { useQuery } from "../../hooks/useQuery";
import { Limit } from "./filters/limit";
import { OrderSide } from "./order/orderSide";
import { UnbookedAmount } from "./order/unbookedAmount";
import { LiquidityScore } from "./order/liquidityScore";
import { Restricted } from "./filters/restricted";
import { BondQuality } from "./order/bondQuality";
import { PercentAdv } from "./order/percentAdv";
import { ExpectedCost } from "./order/expectedCost";
import { useAsyncDispatch } from "../../hooks/useAsyncDispatch";
import { Ticker } from "./order/ticker";
import { Coupon } from "./order/coupon";
import { Maturity } from "./order/maturity";
import { Isin } from "./order/isin";

import "./header.scss";
import { CompositePrices } from "../../hooks/usePrices";
import { CompositePrice } from "./order/compositePrice";
import { OrderLeaves } from "./order/orderLeaves";
import { Currency } from "./order/currency";

export type OrderSummaryProps = {
    prices: CompositePrices;
};

export default function OrderSummary({ prices }: OrderSummaryProps) {
    const dispatch = useAsyncDispatch();

    const params = useParams<MarketDepthParams>();
    const orderNumber = Number(params.orderNumber);

    const query = useQuery();
    const assetId = query.assetId;

    useEffect(() => {
        batch(() => {
            dispatch(fetchOrderSummary(orderNumber));
            dispatch(fetchOrderMetrics(orderNumber));
            dispatch(fetchBrokerDetails(orderNumber));
        });
    }, [dispatch, orderNumber]);

    useEffect(() => {
        if (assetId)
            batch(() => {
                dispatch(fetchAxes(assetId));
                dispatch(fetchLiquidityScoreData({ cusip: assetId, useInvariantID: false }));
            });
    }, [dispatch, assetId]);

    useEffect(() => {
        dispatch(fetchOrderMetrics(orderNumber));
    }, [dispatch, orderNumber]);

    return (
        <div className="book summary">
            <div className="row">
                <ToggleRoute />
                <OrderSide />
                <Ticker />
                <Coupon />
                <Maturity />
                <Cusip />
                <Isin />
                <Currency />
                <BondQuality />
                <div className="flex-fill" />
            </div>
            <div className="row">
                <CompositePrice prices={prices} />
                <UnbookedAmount />
                <OrderLeaves />
                <LiquidityScore />
                <PercentAdv />
                <ExpectedCost />
            </div>
            <div className="row">
                <SourceType />
                <MinSize />
                <Restricted />
                <Limit />
            </div>
        </div>
    );
}

import React from "react";
import {useDispatch, useSelector} from "react-redux";
import {filterLimit} from "../../../redux/actions";
import {AppState} from "../../../redux/store";
import {AtwTooltip} from "../../../atw/atwTooltip";
import {AtwCheckbox} from "../../../atw/AtwCheckbox";

export function Limit() {
    const dispatch = useDispatch();

    const isChecked = useSelector<AppState, boolean | null>(state => state.filters.limit ?? null);
    const limitValue = useSelector<AppState, number | null>(state => state.orderSummary.order?.limitValue ?? null);

    return (
        <div className="limit field">
            <AtwTooltip className="control" message={"Only show axes within the order limit"}>
                <AtwCheckbox
                    disabled={!limitValue}
                    checked={isChecked}
                    onChange={(checked: boolean) => dispatch(filterLimit(checked))}
                >Limit {limitValue ? limitValue.toString() : "N/A"}</AtwCheckbox>
            </AtwTooltip>
        </div>
    );
}

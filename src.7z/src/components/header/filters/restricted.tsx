import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { filterRestricted } from "../../../redux/actions";
import { AppState } from "../../../redux/store";
import {AtwTooltip} from "../../../atw/atwTooltip";
import {AtwCheckbox} from "../../../atw/AtwCheckbox";

export function Restricted() {
    const dispatch = useDispatch();

    const isChecked = useSelector<AppState, boolean | null>(state => state.filters.hideRestricted ?? null);
    const isDisabled = useSelector<AppState, boolean>(state => {
        return state.filters.restrictedBrokers?.size === 0 ?? true;
    });

    return (
        <div className="restricted field">
            <AtwTooltip message={"check to apply broker restriction to filter grid"}>
                <AtwCheckbox
                    disabled={isDisabled}
                    checked={isChecked}
                    onChange={checked => dispatch(filterRestricted(checked))}
                >Hide Restricted(!)</AtwCheckbox>
            </AtwTooltip>
        </div>
    );
}

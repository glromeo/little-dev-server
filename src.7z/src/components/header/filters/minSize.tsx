import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { filterMinSize } from "../../../redux/actions";
import { AppState } from "../../../redux/store";
import {formatQuantity, Quantity} from "../../../utils";
import {AtwTooltip} from "../../../atw/atwTooltip";
import {AtwInput} from "../../../atw/AtwInput";

const VALID_REGEX = /^\d+[KM]?$/i;

export function MinSize() {
    const dispatch = useDispatch();

    const minSize = useSelector<AppState, string | undefined>(state => state.filters.minSize);

    // note: internally AWC masked control uses this - https://imask.js.org/guide.html#masked-pattern
    return (
        <div className="min-size field">
            <label>Min Display Sz</label>
            <AtwTooltip message={"enter min size to filter grid"}>
                <AtwInput
                    isValid={value => VALID_REGEX.test(value)}
                    onChange={(value) => {
                        if (value !== minSize) {
                            dispatch(filterMinSize(value as Quantity));
                        }
                    }}
                    format={value => formatQuantity({value})}
                    value={minSize}
                />
            </AtwTooltip>
        </div>
    );
}

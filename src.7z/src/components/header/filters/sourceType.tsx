import React, { useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { filterSource } from "../../../redux/actions";
import { AppState } from "../../../redux/store";
import { Axes, AxeType } from "../../../models/axe";

// export function SourceType() {
//     const dispatch = useDispatch();
//     const [opened, setOpened] = useState<boolean>(false);
//
//     const getFiltered = (groups: AuxSelectOptionGroup[]): AxeType[] => {
//         const list: AuxSelectOption[] = [];
//         let filtered = groups
//             .reduce((acc: AuxSelectOption[], group: AuxSelectOptionGroup) => [...acc, ...group.values], list)
//             .filter((option: AuxSelectOption) => (option.isSelected ? true : false))
//             .map((option: AuxSelectOption) => option.value);
//         return filtered;
//     };
//
//     const selected = useSelector<AppState, Set<AxeType>>(state => state.filters.sources);
//     const axes = useSelector<AppState, Axes>(state => state.axes);
//
//     const data: AuxSelectOptionGroup[] = useMemo(() => {
//         // TODO: check with Nick Matterson whether the set of sources should be the cumulative
//         //  one or only limited to the focused side (Bid/Ask)
//         return [
//             {
//                 values: [...new Set([...axes.bid.map(axe => axe.type), ...axes.ask.map(axe => axe.type)])].map(
//                     axeType => {
//                         let displayValue;
//                         switch (axeType) {
//                             case "AXE":
//                                 displayValue = "Axes";
//                                 break;
//                             case "ECN":
//                                 displayValue = "ECNs";
//                                 break;
//                             case "IND":
//                                 displayValue = "Indicative Axes";
//                                 break;
//                             default:
//                                 displayValue = "Runs";
//                         }
//                         return {
//                             displayValue: displayValue,
//                             value: axeType,
//                             isSelected: selected.has(axeType!),
//                         };
//                     }
//                 ),
//             },
//         ];
//     }, [axes, selected]);
//
//     function onApply(event: CustomEvent<AuxSelectApplyButtonClickedDetailInterface>) {
//         const filtered = getFiltered(event.detail.newData);
//         dispatch(filterSource(filtered));
//     }
//
//     function onOpened(_event: CustomEvent<AuxSelectDropdownOpenedDetailInterface>) {
//         setOpened(true);
//     }
//
//     function onClosed(_event: CustomEvent<AuxSelectDropdownClosedDetailInterface>) {
//         setOpened(false);
//     }
//
//     function onSelection(_event: CustomEvent<AuxSelectSelectionChangedDetailInterface>) {
//         // because of bug! (in awc) - assume if we get selection when (not) opened - then this is considered a clear event! GRRR!!!
//         if (!opened) dispatch(filterSource([]));
//     }
//
//     return (
//         <div className="source-type field">
//             <label>Type</label>
//             <AuxTooltip>
//                 <AuxSelect
//                     slot="target"
//                     style={{
//                         minWidth: "18.75rem",
//                     }}
//                     role="sources"
//                     type="multiple"
//                     applyButton={true}
//                     data={data}
//                     onApplyButtonClicked={onApply}
//                     onDropdownOpened={onOpened}
//                     onDropdownClosed={onClosed}
//                     onSelectionChanged={onSelection}
//                 />
//                 <div slot="content">please select type(s) to filter grid</div>
//             </AuxTooltip>
//         </div>
//     );
// }

export function SourceType({}:any) {
    return (
        <div/>
    )
}
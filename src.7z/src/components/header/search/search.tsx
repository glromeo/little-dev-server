import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { fetchAxes } from "../../../redux/actions";
import { AppState } from "../../../redux/store";
import { useAsyncDispatch } from "../../../hooks/useAsyncDispatch";
import { ApiError } from "../../../models/alerts";

interface Point {
    x: number;
    y: number;
}

export default function Search() {
    const [position, setPosition] = useState<Point>({ x: 0, y: 0 });
    const [hasError, setHasError] = useState<boolean>(false);
    const searchBarReference = React.useRef(null);
    const timeoutRef = React.useRef<NodeJS.Timeout | null>();
    const dispatch = useAsyncDispatch();

    const error = useSelector<AppState, ApiError | undefined>(state => state.search.error);

    const onSearch = (e: CustomEvent<any>) => {
        const identifier = e.detail.submitValue.searchValue;
        if (identifier) {
            dispatch(fetchAxes(identifier));
        }
    };

    useEffect(() => {
        function updatePosition() {
            if (searchBarReference && searchBarReference.current) {
                const rect = (searchBarReference!.current! as any).getBoundingClientRect();
                setPosition({
                    x: rect.left,
                    y: rect.bottom,
                });
            }
        }

        updatePosition();
    }, [dispatch]);

    useEffect(() => {
        setHasError(error !== undefined);
        if (error !== undefined) {
            timeoutRef.current = setTimeout(() => {
                setHasError(false);
            }, 5000);
        }
        return () => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
        };
    }, [error]);

    return (
        <div className="search field">
            {/*<AuxTooltip>*/}
            {/*    <AuxSearchField role="assetSearch" ref={searchBarReference} slot="target" onClickSearch={onSearch} />*/}
            {/*    <div slot="content">please enter an asset identifier</div>*/}
            {/*</AuxTooltip>*/}
            {hasError ? (
                <div className="search-error" style={{ top: position.y, left: position.x }}>
                    {error?.message ?? null}
                </div>
            ) : null}
        </div>
    );
}

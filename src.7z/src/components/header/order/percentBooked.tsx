import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function PercentBooked() {
    const percentBooked = useSelector<AppState, number | null>(
        ({ orderSummary }) => orderSummary.order?.percentBooked ?? null
    );
    return (
        <div className="percent-booked field">
            <label>BKD</label>
            <span data-test-id="percent-booked">
                {percentBooked !== null ? `${Number(percentBooked.toPrecision(5))}%` : "N/A"}
            </span>
        </div>
    );
}

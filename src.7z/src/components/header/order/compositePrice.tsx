import { CompositePrices } from "../../../hooks/usePrices";

export type CompositePriceProps = {
    prices: CompositePrices;
};

export function CompositePrice({ prices }: CompositePriceProps) {
    return (
        null && (
            <div className="composite-price field">
                <label>Triton</label>
                <span data-test-id="composite-price">
                    {prices.bid.Triton.toPrecision(5) ?? "-"} / {prices.ask.Triton.toPrecision(5) ?? "-"}
                </span>
            </div>
        )
    );
}

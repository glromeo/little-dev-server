import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function BondQuality() {
    const quality = useSelector<AppState, string>(({ orderSummary }) => {
        const bondQuality = orderSummary.security?.bondQuality;
        if (bondQuality === "HY") {
            return "HY - Price";
        } else if (bondQuality === "IG") {
            return "IG - Sprd";
        } else {
            return "N/A";
        }
    });
    return (
        <div className="bond-quality field">
            <span data-test-id="bond-quality">{quality}</span>
        </div>
    );
}

import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";
import { BondQualityType } from "../../../models/security";
import { formatSpread } from "../../../utils";

export function ExpectedCost() {
    const bondQuality = useSelector<AppState, BondQualityType | undefined>(
        ({ orderSummary }) => orderSummary.security?.bondQuality
    );
    let expectedCost = useSelector<AppState, string | null>(({ orderMetrics }) => {
        if (bondQuality === "IG") {
            const spread = orderMetrics?.expectedCost ?? null;
            if (spread !== null) {
                return formatSpread({ value: spread }, "N/A");
            } else {
                return null;
            }
        } else {
            const price = orderMetrics?.expectedCostBps;
            return price?.toFixed(2) ?? null;
        }
    });
    return (
        <div className="expected-cost field">
            <label>Expctd Cost</label>
            <span data-test-id="expected-cost">{expectedCost ?? "N/A"}</span>
        </div>
    );
}

import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function PercentAdv() {
    const percentAdv = useSelector<AppState, number | null>(({ orderMetrics }) => {
        return orderMetrics?.advForecastPct ?? null;
    });
    return (
        <div className="percent-adv field">
            <label>%ADV</label>
            <span data-test-id="percent-adv">
                {percentAdv !== null && percentAdv !== null ? percentAdv.toPrecision(3) : "N/A"}
            </span>
        </div>
    );
}

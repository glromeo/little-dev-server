import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Ticker() {
    const ticker = useSelector<AppState, string | undefined>(state => state.orderSummary.security?.ticker);
    return (
        <div className="ticker field">
            <span data-test-id="ticker">{ticker ?? "N/A"}</span>
        </div>
    );
}

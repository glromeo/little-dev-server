import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Coupon() {
    const coupon = useSelector<AppState, number | undefined>(state => state.orderSummary.security?.couponValue);
    return (
        <div className="coupon field">
            <span data-test-id="coupon">{coupon ?? "N/A"}</span>
        </div>
    );
}

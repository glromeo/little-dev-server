import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Currency() {
    const currency = useSelector<AppState, string | null>(
        ({ orderSummary }) => orderSummary.order?.priceCurrency ?? null
    );
    return (
        <div className="currency field">
            <label>CCY</label>
            <span data-test-id="currency">{currency ?? "N/A"}</span>
        </div>
    );
}

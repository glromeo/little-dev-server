import { Security } from "../../../models/security";
import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Isin() {
    const security = useSelector<AppState, Security | null>(({ orderSummary }) => orderSummary.security);
    return (
        <div className="isin field">
            <label>ISIN</label>
            <span data-test-id="isin">{security?.isin ?? "N/A"}</span>
        </div>
    );
}

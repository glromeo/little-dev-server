import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Maturity() {
    const maturity = useSelector<AppState, string | undefined>(state => state.orderSummary.security?.maturity);
    return (
        <div className="maturity field">
            <span data-test-id="maturity">{maturity ? new Date(maturity).toLocaleDateString() : "N/A"}</span>
        </div>
    );
}

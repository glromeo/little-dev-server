import { formatAmount } from "../../../utils";
import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function UnbookedAmount() {
    const remaining = useSelector<AppState, number | null>(
        ({ orderSummary }) => orderSummary.order?.unbookedAmount ?? null
    );
    return (
        <div className="unbooked-amount field">
            <label>UnBkd Amnt</label>
            <span data-test-id="remaining-size">{remaining !== null ? formatAmount(remaining) : "N/A"}</span>
        </div>
    );
}

import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function LiquidityScore() {
    const liquidityScore = useSelector<AppState, number | null>(state => state.liquidityScore);
    return (
        <div className="liquidity-score field">
            <label>Lqdty Score</label>
            <span data-test-id="liquidity-score">{liquidityScore ?? "N/A"}</span>
        </div>
    );
}

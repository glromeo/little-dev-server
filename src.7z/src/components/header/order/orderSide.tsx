import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function OrderSide() {
    const side = useSelector<AppState, string | undefined>(({ orderSummary }) => orderSummary.order?.side);
    return (
        <div className="order-side field">
            <span data-test-id="order-side">{side ?? "N/A"}</span>
        </div>
    );
}

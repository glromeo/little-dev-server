import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";
import { formatAmount } from "../../../utils";

export function OrderLeaves() {
    const orderLeaves = useSelector<AppState, number | null>(
        ({ orderSummary }) => orderSummary.order?.orderLeaves ?? null
    );
    return (
        <div className="order-leaves field">
            <label>Order Leaves</label>
            <span data-test-id="order-leaves">{orderLeaves !== null ? formatAmount(orderLeaves) : "N/A"}</span>
        </div>
    );
}

import { Security } from "../../../models/security";
import { useSelector } from "react-redux";
import { AppState } from "../../../redux/store";

export function Cusip() {
    const security = useSelector<AppState, Security | null>(({ orderSummary }) => orderSummary.security);
    return (
        <div className="cusip field">
            <label>CUSIP</label>
            <span data-test-id="cusip">{security?.cusip ?? "N/A"}</span>
        </div>
    );
}

import { useHistory, useLocation, useParams } from "react-router-dom";
import { AppState } from "../../redux/store";
import { useDispatch, useSelector } from "react-redux";
import { MarketDepthParams } from "../marketDepth";
import { useCallback, useMemo } from "react";
import { clearAxes, clearOrder } from "../../redux/actions";
import {AtwToggle} from "../../atw/AtwToggle";

type RouteControl = {
    route: string;
};

export type ToggleSearchProps = {
    onToggle: any;
};

export function ToggleRoute() {
    const history = useHistory();
    const { orderNumber: routeOrdNum } = useParams<MarketDepthParams>();
    const { search } = useLocation();

    const storeOrdNum = useSelector<AppState, number | null>(({ orderSummary }) => orderSummary.orderNumber);
    const orderNumber = Number(storeOrdNum ?? routeOrdNum);
    const hasOrder = !isNaN(orderNumber);

    const routes: RouteControl[] = useMemo(
        () => [
            {
                label: "Order",
                route: `/order/${orderNumber}`,
                disabled: !hasOrder,
            },
            {
                label: "Search",
                route: `/search`,
            },
        ],
        [orderNumber, hasOrder]
    );

    const dispatch = useDispatch();

    const onChange = useCallback(
        ({ detail: { data } }) => {
            dispatch(clearAxes());
            dispatch(clearOrder());

            const control = data as RouteControl;
            history.push(`${control.route}${search}`);
        },
        [history, search, dispatch]
    );

    return (
        <div className="toggle-route">
            <AtwToggle
                value={/market-depth\/search/.test(window.location.pathname) ? "Search" : "Order"}
                options={["Order","Search"]}
                onChange={onChange}
            />
        </div>
    );
}

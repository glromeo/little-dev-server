import { ToggleRoute } from "./toggleRoute";
import Search from "./search/search";
import { MinSize } from "./filters/minSize";
import { SourceType } from "./filters/sourceType";

import "./header.scss";

export default function SearchSummary() {
    return (
        <div className="search summary">
            <div className="row">
                <ToggleRoute />
                <Search />
                {/*<Cusip security={security} />*/}
            </div>
            <div className="row" />
            <div className="row">
                <SourceType />
                <MinSize />
            </div>
        </div>
    );
}

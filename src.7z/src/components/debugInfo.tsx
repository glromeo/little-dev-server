import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { AppState } from "../redux/store";
import { Order } from "../models/order";
import { Security } from "../models/security";

/**
 * The purpose of this component is to add a hidden row to the summary section that expands to debug information
 * when a secret key sequence is pressed. This is fundamental to troubleshoot in production and allows us to
 * avoid depending on console.log.
 *
 * @constructor
 */
export default function DebugInfo() {
    const [display, setDisplay] = useState<boolean>(false);

    const keydownCallback = useCallback(event => {
        if (event.key === "X" && event.ctrlKey) {
            event.preventDefault();
            event.stopPropagation();
            setDisplay(true);
        } else {
            setDisplay(false);
        }
    }, []);

    useEffect(() => {
        window.addEventListener("keydown", keydownCallback);
        return () => {
            window.removeEventListener("keydown", keydownCallback);
        };
    }, [keydownCallback]);

    const order = useSelector<AppState, Order | null>(state => state.orderSummary.order);
    const asset = useSelector<AppState, Security | null>(state => state.orderSummary.security);

    const alerts = useSelector<AppState, Record<string, string[]>>(state => state.debug);

    return display ? (
        <div className="debug-info">
            <div className="item">
                <label>Location:</label>
                <span>{String(window.location)}</span>
            </div>
            <div className="item">
                <label>Has Order:</label>
                <span>{order ? "true" : "false"}</span>
            </div>
            <div className="item">
                <label>Order Number:</label>
                <span>{order?.ordNum}</span>
            </div>
            <div className="item">
                <label>Has Asset:</label>
                <span>{asset ? "true" : "false"}</span>
            </div>
            <div className="item">
                <label>Asset CUSIP/ISIN:</label>
                <span>
                    {asset?.cusip}/{asset?.isin}
                </span>
            </div>
            {Object.entries(alerts).map(([label, lines]) => (
                <div className="item" key={label}>
                    <label>{label}</label>
                    <span>
                        {lines.map((line: string, idx: number) => {
                            return <div key={idx}>{line}</div>;
                        })}
                    </span>
                </div>
            ))}
        </div>
    ) : null;
}

import React from "react";

import { useSelector } from "react-redux";
import { AppState } from "../../redux/store";
import { CompositePrices } from "../../models/settings";

function AuxPicklist({}:any) {
    return null;
}

export function CompositePrice() {
    const compositePrices = useSelector<AppState, CompositePrices>(state => state.settings.compositePrices);
    const getData = () =>
        compositePrices.map((composite: string) => {
            return {
                label: composite,
                tooltip: composite,
            };
        });
    return (
        <div>
            <AuxPicklist
                sourceLabel="Show Composite Prices"
                allowDuplicates={false}
                hasSelectedOnly={false}
                sourceData={getData()}
                hasSearch={false}
            />
        </div>
    );
}

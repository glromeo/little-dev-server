import { Axe, AxeSide, AxeSort } from "../models/axe";

import "./priceOverlay.scss";
import { PriceSource } from "../hooks/usePrices";
import {AtwTooltip} from "../atw/atwTooltip";

export type PriceOverlayProps = {
    side: AxeSide;
    prices: Record<PriceSource, number | null>;
    axes: Axe[];
    sort: {
        field: keyof Axe;
        dir: AxeSort;
    };
    scroll: number;
    children: React.ReactNode;
};

const HEADER_HEIGHT = 43;
const FIRST_ROW_BASELINE = 43 + 25;
const ROW_HEIGHT = 25;

export function PriceOverlay({ side, prices, axes, sort, scroll = 0, children }: PriceOverlayProps) {
    function toPosition(index: number) {
        return (index > 0 ? FIRST_ROW_BASELINE + ROW_HEIGHT * index : HEADER_HEIGHT) - scroll;
    }

    const position =
        (sort.dir === "desc" && side === "Ask") || (sort.dir === "asc" && side === "Bid")
            ? (price: number): number => toPosition(axes.findIndex(axe => axe.price < price))
            : (price: number): number => toPosition(axes.findIndex(axe => axe.price > price));

    return (
        <div data-side={side} className="price-overlay">
            {sort.field === "price"
                ? Object.entries(prices)
                      .filter(([name, price]) => price !== null)
                      .map(([name, price]) => {
                          const top = price ? position(price) : -1;
                          return price !== null && top >= HEADER_HEIGHT ? (
                              <div key={name} className={"price-line"} style={{ top: `${top - 1}px` }}>
                                  <div className="price-label" style={{ top: top > HEADER_HEIGHT ? -8 : 0 }}>
                                      <AtwTooltip message={name}>{price.toFixed(2)}</AtwTooltip>
                                  </div>
                              </div>
                          ) : null;
                      })
                : null}
            {children}
        </div>
    );
}

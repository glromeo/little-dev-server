import { OrderMetrics } from "../models/order";
import { createError } from "../models/alerts";
import { apiGet } from "./apiUtils";

export type RawOrderMetric = {
    event: string;
    key: string;
    source: string;
    touchCount: number;
    type: "MI" | "EC" | "EC_BPS" | "ADV" | "ADV_PCT";
    value: number;
};

export async function getTcaOrderMetrics(orderNumber: number): Promise<OrderMetrics> {
    try {
        const raw = await apiGet<RawOrderMetric[]>(`/api/tca/metrics/v1/order/${orderNumber}`, {
            fixture: `/order-metrics/${orderNumber}`,
        });
        const metrics = {} as OrderMetrics;
        for (const { type, value } of raw) {
            switch (type) {
                case "EC":
                    metrics.expectedCost = value;
                    continue;
                case "EC_BPS":
                    metrics.expectedCostBps = value;
                    continue;
                case "ADV":
                    metrics.advForecast = value;
                    continue;
                case "ADV_PCT":
                    metrics.advForecastPct = value;
                    continue;
            }
        }
        return metrics;
    } catch ({ message }) {
        if (!/Unexpected end of JSON input/.test(message)) {
            throw createError("Error fetching Expected Cost", message);
        }
    }
    return {};
}

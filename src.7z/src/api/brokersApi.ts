import { BrokerDetails } from "./../models/brokers";
import { createError } from "../models/alerts";
import { apiQuery } from "./apiUtils";

const brokerAllocationsQuery = `query fiOrderSummary($ordNum: Int!, $brokerList: [Int!]) {
  fiOrderSummary(ordNum: $ordNum, brokerList: $brokerList) {
    brokerAllocations {
      broker {
        ticker,
        name,
        shortName,
        code,
      }
      availablePlacementQuantity,
      eligiblePlacementQuantity,
      eligiblePlacementQuantityAsPct
    }
    brokerEntity {
      key,
      value
    }
  }
}`;

type BrokerEntity = {
    key: string;
    value: string[];
};

export async function queryBrokerDetails(orderNumber: number, brokerList: number[] = []): Promise<BrokerDetails> {
    try {
        const {
            fiOrderSummary: { brokerAllocations, brokerEntity },
        } = await apiQuery<{ ordNum: number; brokerList: number[] }, any>(
            brokerAllocationsQuery,
            {
                ordNum: orderNumber,
                brokerList,
            },
            { fixture: `/broker-details/${orderNumber}` }
        );
        return {
            allocations: brokerAllocations,
            entities: brokerEntity.reduce((entities: Record<number, string>, { key, value }: BrokerEntity) => {
                for (const code of value) {
                    entities[Number(code)] = key;
                }
                return entities;
            }, {}),
        };
    } catch (error) {
        if (typeof error === "string") {
            throw error;
        } else {
            throw createError("Failed to query broker details", error.message);
        }
    }
}

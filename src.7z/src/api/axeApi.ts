import { Axe, AxeExpiryType, Axes, AxeSide, AxeType } from "../models/axe";
import { DebugInfo, dispatchDebugInfo } from "./../utils";
import { createError } from "../models/alerts";
import { apiGet } from "./apiUtils";

/**
 * This is the raw Axe returned by the API. For each column that has to be displayed in the UI create a corresponding
 * field in the model/Axe and provide mapping in the mapRawAxe function below...
 */
export type RawAxe = {
    id: string;
    actionableFlag: boolean;
    actualSize: number;
    assetId: string;
    axeSubtype: string;
    axeType: string;
    benchmarkAssetId: string;
    benchmarkSecurityId: string;
    benchmarkSecurityIdType: string;
    brokerCode: number;
    brokerCode2: number;
    brokerName: string;
    createTime: string | null;
    creator: string;
    displaySize: string;
    ecnAxeId: string;
    effectiveUtcDate: string;
    effectiveTime: string | null;
    expiryTime: string | null;
    expiryType: string;
    externalAxeId: string;
    hedgeAssetId: string;
    hedgeAssetIdType: string;
    internalComment: string;
    marketYield: number;
    marketYieldType: string;
    minimumSize: number;
    modifier: string;
    modifyTime: string | null;
    naturalFlag: true;
    orderNumber: number;
    originalSource: string;
    previousEcnAxeId: string;
    price: number;
    priceCurrencyCode: string;
    priceType: string;
    qualifier: string;
    quality: string;
    qualityScore: number;
    riskKey: number;
    scope: string;
    securityId: string;
    securityIdType: string;
    settleTime: string | null;
    source: string;
    sourceComment: string;
    speed: number;
    speedUnits: string;
    spotOption: string;
    spread: number;
    status: string;
    submitter: string;
    touchCount: number;
    tradedPrice: number;
    transactionType: string;
};

type AxeApiResponse = {
    results: {
        AXE_TRANSACTION_TYPE_BUY?: {
            axes: RawAxe[];
            errorMessage: string;
        };
        AXE_TRANSACTION_TYPE_SELL?: {
            axes: RawAxe[];
            errorMessage: string;
        };
        AXE_TRANSACTION_TYPE_BID?: {
            axes: RawAxe[];
            errorMessage: string;
        };
        AXE_TRANSACTION_TYPE_OFFER?: {
            axes: RawAxe[];
            errorMessage: string;
        };
        AXE_TRANSACTION_TYPE_UNSPECIFIED?: {
            axes: RawAxe[];
            errorMessage: string;
        };
    };
};

export async function getAxesByAssetId(assetId: string): Promise<Axes> {
    try {
        const raw = await apiGet<AxeApiResponse>(`/api/investing/axe/v1/axes/${assetId}`, {
            fixture: `/axes/${assetId}`,
        });
        let { results }: AxeApiResponse = raw;
        if (Object.keys(raw.results).length === 0) {
            return { bid: [], ask: [] };
        } else if (results.AXE_TRANSACTION_TYPE_UNSPECIFIED?.errorMessage) {
            throw createError("Error fetching Axes", results.AXE_TRANSACTION_TYPE_UNSPECIFIED.errorMessage);
        } else {
            return mapRawResponse(raw);
        }
    } catch (error) {
        throw createError("Error fetching Axes", error.message);
    }
}

class AxesSummary implements DebugInfo {
    filtered: number;
    missingBroker: number;
    missingPriceOrSize: number;
    excludedAxeType: number;

    constructor(public label: string, public total: number) {
        this.filtered = 0;
        this.missingBroker = 0;
        this.missingPriceOrSize = 0;
        this.excludedAxeType = 0;
    }

    get text(): string {
        let message = `total: ${this.total}, filtered: ${this.filtered}\n`;
        if (this.missingBroker > 0) {
            message += `${this.missingBroker} axes without broker code\n`;
        }
        if (this.missingPriceOrSize > 0) {
            message += `${this.missingPriceOrSize} axes with no price and no size\n`;
        }
        if (this.excludedAxeType > 0) {
            message += `${this.excludedAxeType} axes with excluded type [AUC | BAXE_EQ | PB_AXE | SECLEND | ADHOC]\n`;
        }
        return message;
    }
}

export function mapRawResponse({ results }: AxeApiResponse): Axes {
    const bidAndSell = [
        ...(results.AXE_TRANSACTION_TYPE_BID?.axes ?? []),
        ...(results.AXE_TRANSACTION_TYPE_SELL?.axes ?? []),
    ];
    const bidSummary = new AxesSummary("Bid Axes (BID & SELL)", bidAndSell.length);
    const bid = bidAndSell.filter(filterRawAxe(bidSummary)).map(mapRawAxe);
    dispatchDebugInfo(bidSummary);

    const offerAndBuy = [
        ...(results.AXE_TRANSACTION_TYPE_OFFER?.axes ?? []),
        ...(results.AXE_TRANSACTION_TYPE_BUY?.axes ?? []),
    ];
    const askInfo = new AxesSummary(`Ask Axes (OFFER & BUY)`, offerAndBuy.length);
    const ask = offerAndBuy.filter(filterRawAxe(askInfo)).map(mapRawAxe);
    dispatchDebugInfo(askInfo);

    dispatchDebugInfo({
        label: "Other Axes",
        text: `${results.AXE_TRANSACTION_TYPE_UNSPECIFIED?.axes?.length ?? "NONE"} with UNSPECIFIED transaction type`,
    });

    let error = [
        results.AXE_TRANSACTION_TYPE_BID?.errorMessage ?? "",
        results.AXE_TRANSACTION_TYPE_SELL?.errorMessage ?? "",
        results.AXE_TRANSACTION_TYPE_OFFER?.errorMessage ?? "",
        results.AXE_TRANSACTION_TYPE_BUY?.errorMessage ?? "",
        results.AXE_TRANSACTION_TYPE_UNSPECIFIED?.errorMessage ?? "",
    ]
        .filter(e => e)
        .join("\n");

    return {
        bid,
        ask,
        error,
    };
}

function filterRawAxe(debugInfo: AxesSummary) {
    return function filterRawAxe(raw: RawAxe): boolean {
        const hasBroker = Boolean(raw.brokerCode);
        if (!hasBroker) debugInfo.missingBroker++;

        const hasPriceOrSize = Boolean(raw.price || raw.actualSize);
        if (!hasPriceOrSize) debugInfo.missingPriceOrSize++;

        const validAxeType = acceptRawAxe(raw);
        if (!validAxeType) debugInfo.excludedAxeType++;

        if (hasBroker && hasPriceOrSize && validAxeType) {
            return true;
        } else {
            debugInfo.filtered++;
            return false;
        }
    };
}

export function mapRawAxe(raw: RawAxe): Axe {
    return {
        type: mapType(raw),
        id: raw.id,
        side: mapAxeSide(raw),
        actionableFlag: raw.actionableFlag,
        size: raw.actualSize,
        assetId: raw.assetId,
        axeSubtype: raw.axeSubtype,
        axeType: AXE_TYPES[raw.axeType],
        benchmarkAssetId: raw.benchmarkAssetId,
        benchmarkSecurityId: raw.benchmarkSecurityId,
        benchmarkSecurityIdType: mapUnknownType(raw.benchmarkSecurityIdType),
        brokerCode: raw.brokerCode,
        brokerCode2: raw.brokerCode2,
        brokerName: raw.brokerName,
        createTime: mapDate(raw.createTime),
        creator: raw.creator,
        displaySize: raw.displaySize,
        ecnAxeId: raw.ecnAxeId,
        effectiveUtcDate: raw.effectiveUtcDate,
        effectiveTime: mapDate(raw.effectiveTime),
        expiryTime: mapTimestamp(raw.expiryTime),
        expiryType: EXPIRY_TYPES[raw.expiryType],
        externalAxeId: raw.externalAxeId,
        hedgeAssetId: raw.hedgeAssetId,
        hedgeAssetIdType: mapUnknownType(raw.hedgeAssetIdType),
        internalComment: raw.internalComment,
        marketYield: raw.marketYield,
        marketYieldType: mapUnknownType(raw.marketYieldType),
        minimumSize: raw.minimumSize,
        modifier: raw.modifier,
        modifyTime: mapDate(raw.modifyTime),
        naturalFlag: raw.naturalFlag,
        orderNumber: raw.orderNumber,
        originalSource: raw.originalSource,
        previousEcnAxeId: raw.previousEcnAxeId,
        price: raw.price,
        priceCurrencyCode: raw.priceCurrencyCode,
        priceType: mapUnknownType(raw.priceType),
        qualifier: raw.qualifier,
        quality: raw.quality,
        qualityScore: raw.qualityScore,
        riskKey: raw.riskKey,
        scope: raw.scope,
        securityId: raw.securityId,
        securityIdType: mapUnknownType(raw.securityIdType),
        settleTime: mapDate(raw.settleTime),
        source: raw.source,
        sourceComment: raw.sourceComment,
        speed: raw.speed,
        speedUnits: raw.speedUnits,
        spotOption: raw.spotOption,
        spread: raw.spread,
        status: raw.status,
        submitter: raw.submitter,
        touchCount: raw.touchCount,
        tradedPrice: raw.tradedPrice,
        transactionType: mapUnknownType(raw.transactionType),
    };
}

function mapAxeSide(raw: RawAxe): AxeSide | undefined {
    switch (raw.transactionType) {
        case "AXE_TRANSACTION_TYPE_BID":
        case "AXE_TRANSACTION_TYPE_SELL":
            return "Bid";
        case "AXE_TRANSACTION_TYPE_BUY":
        case "AXE_TRANSACTION_TYPE_OFFER":
            return "Ask";
    }
}

// simplified - wrt this story https://1a4d.visualstudio.com/trading/_workitems/edit/426280
function mapType(raw: RawAxe): AxeType {
    if (raw.axeType === "AXE_TYPE_DEALER_RUNS") return null;
    if (raw.axeType === "AXE_TYPE_ATN_AXE") return "ECN";
    if (raw.actionableFlag) return "AXE";
    else return "IND";
}

function mapDate(timestamp: string | null): Date | null {
    return timestamp ? stripMillis(new Date(timestamp)) : null;
}

function mapTimestamp(timestamp: string | null): number | null {
    return timestamp ? stripMillis(new Date(timestamp)).getTime() : null;
}

function mapUnknownType(type: string): string | undefined {
    return type === "SECURITY_ID_TYPE_UNSPECIFIED" ? undefined : type;
}

const EXPIRY_TYPES: Record<string, AxeExpiryType> = {
    AXE_EXPIRY_TYPE_GOOD_TILL_DAY: "GOOD_TILL_DAY",
    AXE_EXPIRY_TYPE_GOOD_TILL_CANCELLED: "GOOD_TILL_CANCELLED",
    AXE_EXPIRY_TYPE_GOOD_TILL_TIME: "GOOD_TILL_TIME",
};

// function mapPriceType(raw:RawAxe):string|undefined {
//     switch (raw.priceType) {
//         case "AXE_PRICE_TYPE_FEE": return "FEE";
//         case "AXE_PRICE_TYPE_PRICE": return "PRICE";
//         case "AXE_PRICE_TYPE_RATE": return "RT";
//         case "AXE_PRICE_TYPE_SPREAD": return "SPREAD";
//         case "AXE_PRICE_TYPE_UPFRONT": return "UPFRONT";
//         case "AXE_PRICE_TYPE_YEILD": return "YIELD";
//     }
// }

// function mapTranType(raw:RawAxe):string|undefined {
//     switch (raw.transactionType) {
//         case "AXE_TRANSACTION_TYPE_BUY": return "BUY";
//         case "AXE_TRANSACTION_TYPE_SELL": return "SELL";
//         case "AXE_TRANSACTION_TYPE_BID": return "BID";
//         case "AXE_TRANSACTION_TYPE_OFFER": return "OFFER";
//     }
// }

const AXE_TYPES: Record<string, string> = {
    AXE_TYPE_ADHOC: "ADHOC",
    AXE_TYPE_ATN_AXE: "ATN_AXE",
    AXE_TYPE_AUC: "AUCTION",
    AXE_TYPE_BAXE_AMER: "BAXE_AMER",
    AXE_TYPE_BAXE_ASIA: "BAXE_ASIA",
    AXE_TYPE_BAXE_EMEA: "BAXE_EMEA",
    AXE_TYPE_BAXE_EQ: "BAXE_EQ",
    AXE_TYPE_COMP: "COMP",
    AXE_TYPE_DEALER_RUNS: "DEALER_RUNS",
    AXE_TYPE_SECLEND: "SECLEND",
};

/**
 * We really should do this the other way around by stating the list of accepted types and defaulting to false.
 * I wrote it down this way just because that's what in https://dev.azure.com/1A4D/trading/_workitems/edit/388526
 * also this story - https://1a4d.visualstudio.com/trading/_workitems/edit/426280
 * I will most likely refactor this soon!
 *
 * @param rawAxe
 */
export function acceptRawAxe(rawAxe: RawAxe): boolean {
    switch (rawAxe.axeType) {
        case "SECLEND":
        case "AUC":
        case "ADHOC":
        case "BAXE_EQ":
        case "PB_AXE":
            return false;
        default:
            return acceptAxeStatus(rawAxe);
    }
}

export function acceptAxeStatus(rawAxe: RawAxe): boolean {
    switch (rawAxe.status) {
        case "E":
        case "C":
        case "T":
        case "D":
        case "R":
            return false;
        default:
            return true;
    }
}

function stripMillis(date: Date): Date {
    date.setMilliseconds(0);
    return date;
}

import { recording } from "../rec";
import { createError } from "../models/alerts";
import { getQuery } from "../hooks/useQuery";

const API_KEY =
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIqIiwiYXBwSWQiOiJhbGFkZGludHJhZGVyd29ya3N0YXRpb24iLCJzZXJ2aWNlR3JvdXBzIjpbXSwiZGV0YWlscyI6IltdIiwiaWQiOiJhZTFkMWQ3ZC02YzU4LTQ4ZjYtYWZmNS04NGJlOWFiOTc5ZGQiLCJleHAiOjE3MDM5ODA4MDB9.AgxIg6B4dUhDGbe3xszdM51WvwxFMs_P0h4yP3rpOM4";

function getDelay(time: number) {
    return Date.now() - time;
}

async function apiFetch<R>(path: string, options: any = {}): Promise<R> {
    const { credentials = "include", timeout = 120000 } = options;

    const controller = new AbortController();
    setTimeout(() => controller.abort(), timeout);

    const time = Date.now();

    options = {
        credentials,
        ...options,
        headers: {
            "X-Fixture": options.fixture,
            "VND.com.blackrock.API-Key": API_KEY,
            "VND.com.blackrock.Request-ID": uuid(),
            "VND.com.blackrock.Origin-Timestamp": new Date().toISOString(),
            ...options.headers,
        },
    };

    const promise = fetch(path, {
        ...options,
        signal: controller.signal,
    });
    if (recording) {
        promise.catch(error => recording!.exchange(path, options, { delay: getDelay(time), error }));
    }
    const response = await promise;

    if (response.ok) {
        const promise = response.json();
        if (recording) {
            promise.catch(error => recording!.exchange(path, options, { delay: getDelay(time), error }));
        }
        const json = await promise;
        if (recording) {
            recording.exchange(path, options, {
                delay: getDelay(time),
                headers: response.headers,
                status: response.status,
                body: json,
            });
        }
        return json;
    } else {
        if (recording) {
            recording.exchange(path, options, {
                delay: getDelay(time),
                headers: response.headers,
                status: response.status,
                body: response.statusText,
            });
        }
        throw createError("API Error - " + response.status, response.statusText);
    }
}

export async function apiGet<R>(path: string, options: any = {}): Promise<R> {
    return apiFetch(path, {
        ...options,
        method: "GET",
    });
}

export async function apiPost<P, R>(path: string, body: P, options: any = {}): Promise<R> {
    return apiFetch(path, {
        ...options,
        method: "POST",
        body: JSON.stringify(body),
        headers: {
            "Content-Type": "application/json",
            ...options.headers,
        },
    });
}

type QueryParams<V> = {
    query: string;
    variables: V;
};

interface GraphQLErrorLocation {
    line: number;
    column: number;
    sourceName: string;
}

interface GraphQLError {
    locations: GraphQLErrorLocation[];
    description: string;
    errorType: string;
    extensions: any;
    path: any;
}

export interface QueryResult<R> {
    errors: GraphQLError[];
    data: R;
}

const gqlUser = getQuery().user;

export async function apiQuery<V, R>(query: string, variables: V, options: any = {}): Promise<R> {
    const { data, errors } = await apiPost<QueryParams<V>, QueryResult<R>>(
        "/oemsgqlserver/graphql",
        {
            query,
            variables,
        },
        {
            ...options,
            mode: "cors",
            credentials: "include",
            headers: {
                Authorization: "Basic Z3JvbWVvOkZvbnRTaXplMTM=",
                "X-OEMS-User": gqlUser,
                ...options.headers,
            },
        }
    );
    if (errors) {
        const [{ description }] = errors;
        throw createError("Failed to query broker details", description);
    } else {
        return data;
    }
}

function uuid() {
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, function (c: string) {
        const n = Number(c);
        return (n ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (n / 4)))).toString(16);
    });
}

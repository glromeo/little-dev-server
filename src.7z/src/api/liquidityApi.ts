import { createError } from "../models/alerts";
import { apiPost } from "./apiUtils";

export type LiquidityScoreParams = {
    cusip: string;
    useInvariantID: boolean;
};

export type LiquidityScoreResponse = {
    cusip: string;
    liquidityScore: number;
    maLiquidityScore: number;
    riskDate: string;
    maRiskDate: string;
    message: string | null;
};

export async function getLiquidityScoreData(params: LiquidityScoreParams): Promise<number | null> {
    try {
        const { liquidityScore } = await apiPost<LiquidityScoreParams, LiquidityScoreResponse>(
            "/api/trading/analytics/v1/liquidity-score/latest",
            params,
            { fixture: `/liquidity-score/${params.cusip}` }
        );
        // TODO: message contains useful info ... we should think about how we want to log...
        return liquidityScore;
    } catch ({ message }) {
        if (!/Unexpected end of JSON input/.test(message)) {
            throw createError("Error fetching Liquidity Score", message);
        } else {
            return null;
        }
    }
}

import { getQuery } from "../hooks/useQuery";
import { Axe } from "../models/axe";
import { Order } from "../models/order";
import { Security } from "../models/security";
import { host } from "../utils";

export type ExecutionArgs = {
    order: Partial<Order>;
    axe: Partial<Axe>;
    security: Partial<Security>;
};

const execLocal = () => {
    const query = getQuery();
    switch (query.env?.toLowerCase() || "local") {
        case "dev":
            return "https://dev.blackrock.com";
        case "tst":
            return "https://tst.blackrock.com";
        case "prod":
            return "https://webster.bfm.com";
        case "local":
            return "http://localhost:3001";
        default:
            return "";
    }
};

export function openExecution(args: ExecutionArgs) {
    if (typeof host.bfmCefQuery === "function") {
        host.bfmCefQuery({
            request: "execution:" + JSON.stringify(args),
            persistent: true,
            onSuccess: message => console.log("CEF query - OK", message),
            onFailure: (id, message) => console.log("CEF query - Failed", message),
        });
    } else {
        const baseUrl = execLocal()
            ? "http://localhost:3001"
            : process.env.NODE_ENV === "development"
            ? "https://dev.blackrock.com"
            : "";

        const { order, axe, security } = args;

        window.open(
            `${baseUrl}/apps/execution/${order.ordNum}?side=${order.side}&aid=${axe.ecnAxeId}&asize=${axe.size}&aprice=${axe.price}&aspread=${axe.spread}&ayield=${axe.marketYield}}&aytype=${axe.marketYieldType}&aquality=${security.bondQuality}&acode=${axe.brokerCode}&abroker=${axe.brokerName}&abmk=${axe.benchmarkAssetId}&atime=${axe.createTime}`,
            "Execution",
            "width=1000,height=830"
        );
    }
}

import { OrderSummary } from "../models/order";
import { createError } from "../models/alerts";
import { apiQuery } from "./apiUtils";

const orderSummaryQuery = `
query fiOrderSummary($ordNum: Int!) {
    fiOrderSummary(ordNum: $ordNum) {
        order { 
            ordNum, 
            face, 
            limitValue, 
            priceCurrency, 
            effectiveTranType,
            orderLeaves
        }
        orderDetails {
            ordDetailId,
            quantityBooked
        }
        fiAsset {
            bAsset { 
                assetId, 
                ticker, 
                maturity, 
            },
            bondQuality,
            couponValue,
            cusip,
            isin,
        },
    }
}
`;

export async function queryOrderSummary(orderNumber: number): Promise<OrderSummary> {
    try {
        const {
            fiOrderSummary: {
                order: { ordNum, face, limitValue, priceCurrency, effectiveTranType, orderLeaves },
                orderDetails,
                fiAsset: {
                    bAsset: { assetId, ticker, maturity },
                    bondQuality,
                    couponValue,
                    cusip,
                    isin,
                },
            },
        } = await apiQuery<{ ordNum: number }, any>(
            orderSummaryQuery,
            { ordNum: orderNumber },
            { fixture: `/order-summary/${orderNumber}` }
        );

        const totalBooked = orderDetails.reduce(
            (totalBooked: number, { quantityBooked }: any) => totalBooked + quantityBooked,
            0
        );

        return {
            orderNumber: ordNum,
            order: {
                ordNum,
                side: effectiveTranType === "BUY" ? "Buy" : "Sell",
                unbookedAmount: face - totalBooked,
                limitValue,
                priceCurrency,
                orderLeaves,
                percentBooked: face ? (totalBooked / face) * 100 : null,
            },
            security: {
                assetId,
                ticker,
                maturity,
                cusip,
                isin,
                bondQuality: bondQuality ?? "HY",
                couponValue,
            },
        };
    } catch (error) {
        if (typeof error === "string") {
            throw error;
        } else {
            throw createError("Failed to query order & asset", error.message);
        }
    }
}

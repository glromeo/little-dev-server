import JSZip from "jszip";
import FileSaver from "file-saver";

export type HttpExchange = { request: string; response: string };

export class Rec {
    http: Record<string, HttpExchange[]> = {};
    ws: { start?: number; out: string[]; in: string[]; time: number[] } = {
        out: [],
        in: [],
        time: [],
    };

    start = Date.now();

    exchange(url: string, request: any, response: any) {
        let key = request.fixture;
        if (!key) {
            console.warn("no fixture specified for ", request.method, url, "url path will be used instead");
            key = url;
        }
        if (!this.http[key]) {
            this.http[key] = [];
        }
        this.http[key].push({ request, response });
    }

    onopen() {
        this.ws.start = Date.now();
    }

    sent(message: string) {
        this.ws.out.push(message);
    }

    received(message: string) {
        this.ws.in.push(message);
        this.ws.time.push(Date.now());
    }

    async download() {
        const zip = new JSZip();
        zip.file("recording.json", JSON.stringify(recording, null, 4));
        const blob = await zip.generateAsync({ type: "blob" });
        FileSaver.saveAs(blob, "recording.zip");
    }
}

export const recording = localStorage.getItem("recording") === "true" ? new Rec() : null;

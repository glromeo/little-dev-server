import { debugInfo, notifyAlert } from "./redux/actions";
import { store } from "./redux/store";
import { Alert, createError } from "./models/alerts";

export const host = window as any as {
    bfmCefQuery?: (args: {
        request: string;
        persistent: boolean;
        onSuccess: (message: string) => void;
        onFailure: (id: string, message: string) => void;
    }) => void;
};

export async function queryHost<T>(path: string): Promise<T> {
    if (host.bfmCefQuery) {
        return new Promise((resolve, reject) => {
            host.bfmCefQuery!({
                request: `GET:${JSON.stringify({ path })}`,
                persistent: true,
                onSuccess: response => resolve(JSON.parse(response)),
                onFailure: (id, message) => {
                    store.dispatch(notifyAlert(new Alert("CEF Query Failure", message, "ERROR")));
                    reject(createError("Query Failed", message));
                },
            });
        });
    } else {
        const response = await fetch(path, { method: "GET" });
        if (response.ok) {
            return response.json();
        } else {
            throw createError("Query Failed", response.statusText);
        }
    }
}

export async function mutateHost<T>(path: string, payload: T): Promise<void> {
    if (host.bfmCefQuery) {
        return new Promise((resolve, reject) => {
            host.bfmCefQuery!({
                request: `PUT:${JSON.stringify({ path, payload })}`,
                persistent: true,
                onSuccess: response => resolve(),
                onFailure: (id, message) => {
                    store.dispatch(notifyAlert(new Alert("CEF Mutation Failure", message, "ERROR")));
                    reject(createError("Mutation Failed", message));
                },
            });
        });
    } else {
        const response = await fetch(path, {
            method: "PUT",
            body: JSON.stringify(payload),
            headers: {
                "Content-Type": "application/json",
            },
        });
        if (response.ok) {
            return response.json();
        } else {
            throw createError("Mutation Failed", response.statusText);
        }
    }
}

export type Quantity = `${number}` | `${number}k` | `${number}K` | `${number}m` | `${number}M` | "0" | "";

export function formatTime({ value: date }: { value: any }) {
    try {
        if (!(date instanceof Date)) {
            date = new Date(Number(date));
        }
        return date.toTimeString().substring(0, 8);
    } catch (ignored) {
        // invalid time value, we don't show anything in the cell
    }
    return "";
}

export function formatTimer({ value }: { value: number }) {
    try {
        return new Date(value).toISOString().substr(11, 8);
    } catch (ignored) {
        // invalid time value, we don't show anything in the cell
    }
    return "";
}

export function parseDate(maturity: string): string {
    const splitDate = maturity.split("-");
    const mm = splitDate[1];
    const yy = splitDate[0].slice(2);
    const dd = splitDate[2];
    return `${mm}/${dd}/${yy}`;
}

export function formatAmount(amount: number) {
    return amount.toLocaleString("en-US");
}

export function formatPrice({ value: price }: { value: any }) {
    return price ? price.toFixed(2) : price === 0 ? "0.00" : "-";
}

export function formatSpread({ value: spread }: { value: any }, na = "-") {
    if (spread) {
        return spread > 0 ? `+${spread.toFixed(2)}` : spread.toFixed(2);
    } else {
        return spread === 0 ? "+0.00" : na;
    }
}

export function formatQuantity({ value: quantity }: { value: any }): Quantity {
    if (quantity) {
        if (quantity >= 1_000_000_000) {
            return `${Math.floor(quantity / 10_000_000) / 100}B` as Quantity;
        }
        if (quantity >= 1_000_000) {
            return `${Math.floor(quantity / 10_000) / 100}M` as Quantity;
        }
        if (quantity >= 1_000) {
            return `${Math.floor(quantity / 10) / 100}K` as Quantity;
        }
        return String(quantity) as Quantity;
    } else {
        return quantity === 0 ? "0" : "";
    }
}

export function parseQuantity(quantity: Quantity): number {
    return quantity ? parseInt(quantity) * scaleFactor(quantity.trim().charAt(quantity.length - 1)) : 0;
}

export type DebugInfo = {
    label: string;
    text: string;
};

export function dispatchDebugInfo(info: DebugInfo) {
    store.dispatch(debugInfo(info.label, info.text));
}

function scaleFactor(scale: string): number {
    switch (scale) {
        case "k":
        case "K":
            return 1_000;
        case "m":
        case "M":
            return 1_000_000;
        case "b":
        case "B":
            return 1_000_000_000;
    }
    return 1;
}
